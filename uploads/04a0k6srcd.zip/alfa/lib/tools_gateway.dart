import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// Import halaman Anda (Pastikan path benar)
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Background Glows
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentGreen.withOpacity(0.15))),
          Positioned(bottom: 100, left: -100, child: _buildGlowOrb(300, lightGreen.withOpacity(0.1))),

          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // SECTION 1: HEADER
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(25, 40, 25, 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildBadge(widget.userRole.toUpperCase()),
                        const SizedBox(height: 15),
                        const Text(
                          "Advanced\nToolkits",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 40,
                            fontWeight: FontWeight.w900,
                            height: 1.0,
                            letterSpacing: -1,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Container(
                          width: 60,
                          height: 4,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [accentGreen, lightGreen]),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // SECTION 2: GRID MENU
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 15,
                      crossAxisSpacing: 15,
                      childAspectRatio: 0.85,
                    ),
                    delegate: SliverChildListDelegate([
                      _buildModernCard("DDoS", Icons.bolt_rounded, "Layer 4/7 Vector", () => _showDDoSTools(context)),
                      _buildModernCard("Network", Icons.language_rounded, "Packet Analysis", () => _showNetworkTools(context)),
                      _buildModernCard("OSINT", Icons.manage_search_rounded, "Cyber Intelligence", () => _showOSINTTools(context)),
                      _buildModernCard("Media", Icons.cloud_download_rounded, "SMM Extractors", () => _showDownloaderTools(context)),
                      _buildModernCard("Utility", Icons.token_rounded, "System Payload", () => _showUtilityTools(context)),
                      _buildModernCard("Database", Icons.storage_rounded, "Archive Access", () => _showComingSoon(context)),
                    ]),
                  ),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 120)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- UI WIDGETS ---

  Widget _buildModernCard(String title, IconData icon, String subtitle, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: glassBg,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: glassBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: Icon(Icons.arrow_outward_rounded, color: lightGreen.withOpacity(0.3), size: 18),
                ),
                Icon(icon, color: lightGreen, size: 34),
                const Spacer(),
                Text(
                  title,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 0.5),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 10, fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBadge(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: lightGreen.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: lightGreen.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 6, height: 6, decoration: BoxDecoration(color: lightGreen, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(color: lightGreen, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2),
          ),
        ],
      ),
    );
  }

  // --- MODAL SHEETS ---

  void _showDDoSTools(BuildContext context) {
    _buildModernModal(context, "DDoS Operation", [
      _modalTile(Icons.api_rounded, "Attack Panel", "Unified stress test interface", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: widget.sessionKey, listDoos: widget.listDoos)));
      }),
      _modalTile(Icons.dns_rounded, "Manage Server", "Control remote VPS assets", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => ManageServerPage(keyToken: widget.sessionKey)));
      }),
    ]);
  }

  void _showNetworkTools(BuildContext context) {
    _buildModernModal(context, "Network Suite", [
      _modalTile(Icons.mail_lock_rounded, "Spam NGL", "Automated anonymous feedback", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
      }),
      _modalTile(Icons.wifi_tethering_off_rounded, "WiFi Killer (Int)", "Local network disruption", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
      }),
      if (widget.userRole.toLowerCase() == "vip" || widget.userRole.toLowerCase() == "owner")
        _modalTile(Icons.router_rounded, "WiFi Killer (Ext)", "Enhanced protocol control", () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey)));
        }),
    ]);
  }

  void _showOSINTTools(BuildContext context) {
    _buildModernModal(context, "OSINT Engine", [
      _modalTile(Icons.contact_page_rounded, "NIK Checker", "Public record identification", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
      }),
      _modalTile(Icons.travel_explore_rounded, "Domain OSINT", "WHOIS & DNS infrastructure", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
      }),
    ]);
  }

  void _showDownloaderTools(BuildContext context) {
    _buildModernModal(context, "SMM Extractors", [
      _modalTile(FontAwesomeIcons.tiktok, "TikTok Pro", "High-speed MP4 extraction (No-WM)", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
      }),
      _modalTile(FontAwesomeIcons.instagram, "Instagram Pro", "Reels & Media downloader", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
      }),
    ]);
  }

  void _showUtilityTools(BuildContext context) {
    _buildModernModal(context, "System Utilities", [
      _modalTile(Icons.qr_code_2_rounded, "QR Generator", "Static & Dynamic QR synthesis", () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
      }),
    ]);
  }

  // --- HELPERS ---

  void _buildModernModal(BuildContext context, String title, List<Widget> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: const EdgeInsets.fromLTRB(25, 15, 25, 40),
          decoration: BoxDecoration(
            color: bgBlack.withOpacity(0.85),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
            border: Border.all(color: glassBorder),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: lightGreen.withOpacity(0.3), borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 30),
              Row(
                children: [
                  Container(width: 4, height: 20, decoration: BoxDecoration(color: lightGreen, borderRadius: BorderRadius.circular(2))),
                  const SizedBox(width: 12),
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                ],
              ),
              const SizedBox(height: 25),
              ...items,
            ],
          ),
        ),
      ),
    );
  }

  Widget _modalTile(IconData icon, String title, String desc, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: ListTile(
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: lightGreen.withOpacity(0.05), borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: lightGreen, size: 24),
        ),
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
        subtitle: Text(desc, style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 11)),
        trailing: Icon(Icons.chevron_right_rounded, color: lightGreen.withOpacity(0.4), size: 20),
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 50)]),
    );
  }

  void _showComingSoon(BuildContext context) {
    HapticFeedback.heavyImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.lock_clock_rounded, color: bgBlack, size: 20),
            const SizedBox(width: 12),
            const Text('PROTOCOL ENCRYPTED: ACCESS DENIED', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 12)),
          ],
        ),
        backgroundColor: lightGreen,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }
}