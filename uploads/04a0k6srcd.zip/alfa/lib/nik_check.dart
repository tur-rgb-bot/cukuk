import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class NikCheckerPage extends StatefulWidget {
  const NikCheckerPage({super.key});

  @override
  State<NikCheckerPage> createState() => _NikCheckerPageState();
}

class _NikCheckerPageState extends State<NikCheckerPage> with TickerProviderStateMixin {
  final TextEditingController _nikController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _data;
  String? _errorMessage;

  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));
    _slideController.forward();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _nikController.dispose();
    super.dispose();
  }

  Future<void> _checkNik() async {
    final nik = _nikController.text.trim();
    if (nik.isEmpty) {
      _showSnackBar("REJECTED: NIK_PAYLOAD_EMPTY", Colors.redAccent);
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _data = null;
    });

    try {
      final response = await http.get(Uri.parse("https://api.siputzx.my.id/api/tools/nik-checker?nik=$nik"));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() => _data = json['data']);
          HapticFeedback.heavyImpact();
        } else {
          setState(() => _errorMessage = "DATA_NOT_FOUND: Invalid NIK signature.");
        }
      } else {
        setState(() => _errorMessage = "UPLINK_ERROR: Server unresponsive.");
      }
    } catch (e) {
      setState(() => _errorMessage = "PROTOCOL_FAILURE: Connection lost.");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    _showSnackBar("COPIED: $label", lightGreen);
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'monospace')),
        backgroundColor: color.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentGreen.withOpacity(0.15))),
          Positioned(bottom: 200, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: SlideTransition(
              position: _slideAnimation,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    _buildHeader(),
                    const SizedBox(height: 30),

                    // Search Section
                    _buildGlassContainer(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("VERIFICATION_PROTOCOL", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 3)),
                          const SizedBox(height: 15),
                          TextField(
                            controller: _nikController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace'),
                            decoration: InputDecoration(
                              hintText: "ENTER 16-DIGIT NIK_SIGNATURE...",
                              hintStyle: const TextStyle(color: Colors.white10, fontSize: 11),
                              filled: true,
                              fillColor: Colors.black.withOpacity(0.3),
                              prefixIcon: Icon(Icons.fingerprint_rounded, color: lightGreen, size: 20),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
                              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: lightGreen.withOpacity(0.3))),
                            ),
                          ),
                          const SizedBox(height: 15),
                          _buildPrimaryButton(),
                        ],
                      ),
                    ),

                    const SizedBox(height: 25),

                    if (_errorMessage != null) _buildErrorState(),

                    // Results Section
                    if (_data != null) ...[
                      _buildResultSection("IDENTITY_STREAM", Icons.admin_panel_settings_rounded, [
                        _infoTile("REGISTRY_ID", _data!["nik"], true),
                        _infoTile("LEGAL_NAME", _data!["data"]["nama"], true),
                        _infoTile("GENDER_BIOMETRIC", _data!["data"]["kelamin"], false),
                        _infoTile("BIRTH_CHRONOLOGY", "${_data!["data"]["tempat_lahir"]}, ${_data!["data"]["tgl_lahir"]}", false),
                        _infoTile("AGE_INDEX", _data!["data"]["usia"], false),
                      ]),
                      const SizedBox(height: 20),
                      _buildResultSection("GEOLOCATION_NODES", Icons.location_searching_rounded, [
                        _infoTile("PROVINCE", _data!["data"]["provinsi"], false),
                        _infoTile("REGENCY", _data!["data"]["kabupaten"], false),
                        _infoTile("DISTRICT", _data!["data"]["kecamatan"], false),
                        _infoTile("VILLAGE", _data!["data"]["kelurahan"], false),
                        _infoTile("FULL_ADDRESS_LOG", _data!["data"]["alamat"], true),
                      ]),
                      const SizedBox(height: 20),
                      _buildResultSection("EXTENDED_METADATA", Icons.hub, [
                        _infoTile("ASTRO_SIGN", _data!["data"]["zodiak"], false),
                        _infoTile("ANNIVERSARY_PULSE", _data!["data"]["ultah_mendatang"], false),
                        _infoTile("MARKET_DAY_INDEX", _data!["data"]["pasaran"], false),
                      ]),
                    ],
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("NIK CHECKER", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
            Text("Citizen OSINT Database Access", style: TextStyle(color: lightGreen, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          ],
        ),
      ],
    );
  }

  Widget _buildPrimaryButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _checkNik,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 60,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            if (!_isLoading) BoxShadow(color: lightGreen.withOpacity(0.15), blurRadius: 15, offset: const Offset(0, 8))
          ],
        ),
        child: Center(
          child: _isLoading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
              : const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.radar_rounded, color: Colors.black, size: 22),
              SizedBox(width: 12),
              Text("INITIATE_SCAN", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultSection(String title, IconData icon, List<Widget> children) {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: lightGreen, size: 18),
              const SizedBox(width: 12),
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2)),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _infoTile(String label, dynamic value, bool showCopy) {
    if (value == null || value.toString().isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: glassBorder),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: lightGreen.withOpacity(0.4), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
                const SizedBox(height: 4),
                Text(value.toString().toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600, fontFamily: 'monospace')),
              ],
            ),
          ),
          if (showCopy)
            IconButton(
              icon: Icon(Icons.content_copy_rounded, color: lightGreen.withOpacity(0.6), size: 16),
              onPressed: () => _copyToClipboard(value.toString(), label),
              constraints: const BoxConstraints(),
              padding: EdgeInsets.zero,
            ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return _buildGlassContainer(
      borderColor: Colors.redAccent.withOpacity(0.3),
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          const Icon(Icons.gpp_maybe_rounded, color: Colors.redAccent, size: 20),
          const SizedBox(width: 15),
          Expanded(child: Text(_errorMessage ?? "SYSTEM_ERROR", style: const TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'monospace'))),
        ],
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}