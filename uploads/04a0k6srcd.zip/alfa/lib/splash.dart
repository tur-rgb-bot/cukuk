import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;
  bool _fadeOutStarted = false;
  bool _videoInitialized = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _scaleController.forward();
    _initializeVideoController();
  }

  void _initializeVideoController() {
    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        if (mounted) {
          setState(() {
            _videoInitialized = true;
          });
          _videoController.setLooping(false);
          _videoController.play();

          _videoController.addListener(() {
            if (!mounted) return;

            final position = _videoController.value.position;
            final duration = _videoController.value.duration;

            if (duration != null &&
                position >= duration - const Duration(seconds: 1) &&
                !_fadeOutStarted) {
              _fadeOutStarted = true;
              _fadeController.forward();
            }

            if (position >= duration) {
              _navigateToDashboard();
            }
          });
        }
      }).catchError((error) {
        if (mounted) {
          setState(() {
            _videoInitialized = false;
          });
          Future.delayed(const Duration(seconds: 3), () {
            if (mounted) {
              _navigateToDashboard();
            }
          });
        }
      });
  }

  void _navigateToDashboard() {
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => DashboardPage(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          // UBAH: Gradasi Hitam ke Hijau Tua
          gradient: LinearGradient(
            colors: [Color(0xFF000000), Color(0xFF0D2310), Color(0xFF1B5E20)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // UBAH: Green particles background
            Positioned.fill(
              child: CustomPaint(
                painter: GreenParticlePainter(),
              ),
            ),

            // Video Box
            if (_videoInitialized)
              Center(
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.8,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(30),
                          // UBAH: Border Hijau
                          border: Border.all(
                            color: Colors.greenAccent.withOpacity(0.3),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.green.withOpacity(0.3),
                              blurRadius: 25,
                              spreadRadius: 5,
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(28),
                          child: AspectRatio(
                            aspectRatio: _videoController.value.aspectRatio,
                            child: VideoPlayer(_videoController),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )
            else
              Center(
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(
                        color: Colors.greenAccent.withOpacity(0.3),
                        width: 1.5,
                      ),
                    ),
                    child: const Center(
                      child: CircularProgressIndicator(
                        // UBAH: Loading Hijau
                        color: Colors.greenAccent,
                        strokeWidth: 3,
                      ),
                    ),
                  ),
                ),
              ),

            // Teks 𝐀𝐋𝐅𝐀 𝐂𝐑𝐀𝐒𝐇
            Positioned(
              bottom: 80,
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(30),
                    // UBAH: Border Hijau
                    border: Border.all(
                      color: Colors.greenAccent.withOpacity(0.4),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.greenAccent.withOpacity(0.2),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(28),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                      child: Text(
                        "𝐀𝐋𝐅𝐀 𝐂𝐑𝐀𝐒𝐇",
                        style: TextStyle(
                          fontSize: 42,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          letterSpacing: 3,
                          shadows: [
                            Shadow(
                              // UBAH: Glow Teks Hijau
                              color: Colors.greenAccent.withOpacity(0.8),
                              blurRadius: 10,
                              offset: const Offset(2, 2),
                            ),
                            Shadow(
                              color: Colors.black.withOpacity(0.8),
                              blurRadius: 15,
                              offset: const Offset(-2, -2),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Decorative elements
            Positioned(
              top: 100,
              left: 50,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.greenAccent.withOpacity(0.1),
                    width: 2,
                  ),
                ),
              ),
            ),

            Positioned(
              bottom: 200,
              right: 60,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.green.withOpacity(0.15),
                    width: 2,
                  ),
                ),
              ),
            ),

            // Fade out effect
            if (_fadeOutStarted)
              FadeTransition(
                opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      // UBAH: Fade to Greenish Black
                      colors: [Color(0xFF000000), Color(0xFF0D2310)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// UBAH: Nama Class & Warna Partikel ke Hijau
class GreenParticlePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.greenAccent.withOpacity(0.15)
      ..style = PaintingStyle.fill;

    const particleSize = 2.0;
    const spacing = 40.0;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        final offsetX = (x % 2 == 0) ? 10.0 : -10.0;
        final offsetY = (y % 2 == 0) ? 10.0 : -10.0;
        canvas.drawCircle(Offset(x + offsetX, y + offsetY), particleSize, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}