import 'dart:convert';
import 'dart:ui';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Import halaman terkait Anda
import 'home_page.dart';
import 'tools_gateway.dart';
import 'anime_home.dart';
import 'bug_sender.dart';
import 'admin_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  // UBAH: Theme Colors ke Hijau Tua & Hitam
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20); // Deep Green
  final Color lightGreen = const Color(0xFF2ECC71);  // Green Accent
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);

  int _selectedTabIndex = 0;
  int onlineUsers = 0;
  int activeConnections = 0;
  late WebSocketChannel channel;

  late PageController _pageController;
  int _currentPage = 0;
  Timer? _carouselTimer;

  @override
  void initState() {
    super.initState();
    _connectToWebSocket();

    _pageController = PageController(initialPage: 0);
    if (widget.news.isNotEmpty) {
      _carouselTimer = Timer.periodic(const Duration(seconds: 6), (Timer timer) {
        if (_currentPage < widget.news.length - 1) {
          _currentPage++;
        } else {
          _currentPage = 0;
        }

        if (_pageController.hasClients) {
          _pageController.animateToPage(
            _currentPage,
            duration: const Duration(milliseconds: 900),
            curve: Curves.easeInOutCubic,
          );
        }
      });
    }
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('wss://ws-alfa.nullxteam.fun'));
      channel.sink.add(jsonEncode({"type": "validate", "key": widget.sessionKey}));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'stats') {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      });
    } catch (e) {
      debugPrint("WS Error: $e");
    }
  }

  @override
  void dispose() {
    _carouselTimer?.cancel();
    _pageController.dispose();
    channel.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // UBAH: Glow Orbs ke Hijau
          Positioned(top: -100, right: -50, child: _buildGlowOrb(250, accentGreen.withOpacity(0.3))),
          Positioned(bottom: -50, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.1))),

          SafeArea(
            child: Column(
              children: [
                _buildCompactAppBar(),
                Expanded(
                  child: _selectedTabIndex == 0 ? _buildMainDashboard() : _getBodyContent(),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildGlassBottomNav(),
    );
  }

  Future<void> _handleLogout() async {
    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF0A0A0A),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text("Terminate Session", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          content: const Text("Hapus data login dan kembali ke halaman awal?", style: TextStyle(color: Colors.white70, fontSize: 14)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("CANCEL", style: TextStyle(color: Colors.white38))),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
              onPressed: () => Navigator.pop(context, true),
              child: const Text("LOGOUT"),
            ),
          ],
        ),
      ),
    );

    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      if (mounted) Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
    }
  }

  Widget _buildMainDashboard() {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      physics: const BouncingScrollPhysics(),
      children: [
        Row(
          children: [
            Expanded(child: _buildStatusCard("Online Users", onlineUsers.toString(), Icons.bolt)),
            const SizedBox(width: 15),
            Expanded(child: _buildStatusCard("Active Conns", activeConnections.toString(), Icons.sensors)),
          ],
        ),
        const SizedBox(height: 25),

        // License Status Card
        _buildGlassContainer(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                children: [
                  _buildCircularProgress(),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("License Status", style: TextStyle(color: Colors.white70, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(widget.expiredDate, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                        const SizedBox(height: 4),
                        // UBAH: Teks Status ke Hijau
                        Text("Active Protection Enabled", style: TextStyle(color: lightGreen, fontSize: 10, fontWeight: FontWeight.w500)),
                      ],
                    ),
                  )
                ],
              ),
              const SizedBox(height: 20),
              const Divider(color: Colors.white10, height: 1),
              const SizedBox(height: 15),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey))),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.1)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.lock_reset_rounded, color: Colors.white70, size: 16),
                            SizedBox(width: 8),
                            Text("PASSWORD", style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => _handleLogout(),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.redAccent.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.logout_rounded, color: Colors.redAccent, size: 16),
                            SizedBox(width: 8),
                            Text("LOGOUT", style: TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
        const SizedBox(height: 25),

        const Text("LATEST UPDATES", style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 15),
        _buildNewsCarousel(),
        const SizedBox(height: 25),

        // UBAH: Manage WhatsApp Sender Card ke Hijau
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: InkWell(
            onTap: () {
              if (context.mounted) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => BugSenderPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role)));
              }
            },
            child: _buildGlassContainer(
              gradient: LinearGradient(
                colors: [accentGreen.withOpacity(0.6), Colors.transparent],
              ),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              child: Row(
                children: [
                  const Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 20),
                  const SizedBox(width: 15),
                  const Text("Manage WhatsApp Sender", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  Icon(Icons.arrow_forward_ios, color: Colors.white.withOpacity(0.5), size: 14),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildNewsCarousel() {
    if (widget.news.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 180,
      child: PageView.builder(
        controller: _pageController,
        itemCount: widget.news.length,
        onPageChanged: (index) => setState(() => _currentPage = index),
        itemBuilder: (context, index) {
          final item = widget.news[index];
          final String mediaUrl = item['url'] ?? item['image'] ?? "";
          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Stack(
                children: [
                  Positioned.fill(child: mediaUrl.isNotEmpty ? NewsMedia(url: mediaUrl, accentColor: lightGreen) : Container(color: Colors.white10)),
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black.withOpacity(0.8)],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 15, left: 15, right: 15,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item['title'] ?? 'New Update', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                        const SizedBox(height: 4),
                        Text(item['desc'] ?? 'Tap to read more...', style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]));
  }

  Widget _buildCompactAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text("Hello, ${widget.username}", style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            // UBAH: Role Label ke Hijau
            Text(widget.role.toUpperCase(), style: TextStyle(color: lightGreen, fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 2)),
          ]),
          Row(
            children: [
              if (widget.role.toLowerCase().contains("reseller"))
                _buildAppBarAction(Icons.storefront, Colors.blueAccent, () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SellerPage(keyToken: widget.sessionKey)));
                }),
              if (widget.role.toLowerCase() == "owner")
                _buildAppBarAction(Icons.admin_panel_settings, Colors.redAccent, () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => AdminPage(sessionKey: widget.sessionKey)));
                }),
              const SizedBox(width: 8),
              _buildGlassContainer(padding: const EdgeInsets.all(8), child: const Icon(Icons.notifications_none, color: Colors.white, size: 20)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAppBarAction(IconData icon, Color color, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(onTap: onTap, child: _buildGlassContainer(padding: const EdgeInsets.all(8), child: Icon(icon, color: color, size: 20))),
    );
  }

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Gradient? gradient}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: glassBorder),
            gradient: gradient,
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildStatusCard(String title, String value, IconData icon) {
    // UBAH: Icon warna Hijau
    return _buildGlassContainer(padding: const EdgeInsets.all(15), child: Row(children: [Icon(icon, color: lightGreen, size: 20), const SizedBox(width: 12), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white38, fontSize: 10)), Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16))])]));
  }

  double _calculateExpiryProgress() {
    try {
      DateTime expiry = DateTime.parse(widget.expiredDate);
      DateTime now = DateTime.now();
      if (expiry.isBefore(now)) return 0.0;
      int remainingSeconds = expiry.difference(now).inSeconds;
      return (remainingSeconds / (30 * 24 * 60 * 60)).clamp(0.0, 1.0);
    } catch (e) {
      return 0.0;
    }
  }

  Widget _buildCircularProgress() {
    double progressValue = _calculateExpiryProgress();
    return SizedBox(
      height: 50, width: 50,
      child: Stack(
        fit: StackFit.expand,
        children: [
          CircularProgressIndicator(value: 1.0, strokeWidth: 4, color: Colors.white.withOpacity(0.05)),
          // UBAH: Progress ke Hijau
          CircularProgressIndicator(
            value: progressValue,
            strokeWidth: 4,
            strokeCap: StrokeCap.round,
            color: progressValue < 0.2 ? Colors.redAccent : lightGreen,
          ),
          Center(child: Text("${(progressValue * 100).toInt()}%", style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  Widget _buildGlassBottomNav() {
    return Container(height: 70, margin: const EdgeInsets.fromLTRB(20, 0, 20, 20), child: _buildGlassContainer(padding: const EdgeInsets.symmetric(horizontal: 10), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_buildNavItem(0, Icons.grid_view_rounded), _buildNavItem(1, FontAwesomeIcons.whatsapp), _buildNavItem(2, Icons.construction), _buildNavItem(3, Icons.play_circle_fill)])));
  }

  Widget _buildNavItem(int index, IconData icon) {
    bool isSelected = _selectedTabIndex == index;
    // UBAH: Warna Seleksi Nav ke Hijau
    return GestureDetector(onTap: () => setState(() => _selectedTabIndex = index), child: AnimatedContainer(duration: const Duration(milliseconds: 300), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: isSelected ? accentGreen.withOpacity(0.3) : Colors.transparent, shape: BoxShape.circle), child: Icon(icon, color: isSelected ? lightGreen : Colors.white38, size: 26)));
  }

  Widget _getBodyContent() {
    switch (_selectedTabIndex) {
      case 1: return HomePage(username: widget.username, password: widget.password, listBug: widget.listBug, role: widget.role, expiredDate: widget.expiredDate, sessionKey: widget.sessionKey);
      case 2: return ToolsPage(sessionKey: widget.sessionKey, userRole: widget.role, listDoos: widget.listDoos);
      case 3: return const HomeAnimePage();
      default: return const SizedBox.shrink();
    }
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  final Color accentColor; // Tambahkan accentColor
  const NewsMedia({super.key, required this.url, required this.accentColor});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return FittedBox(fit: BoxFit.cover, child: SizedBox(width: _controller!.value.size.width, height: _controller!.value.size.height, child: VideoPlayer(_controller!)));
      } else {
        return Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: widget.accentColor, strokeWidth: 2)));
      }
    } else {
      return Image.network(widget.url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade900, child: Icon(Icons.error, color: widget.accentColor)));
    }
  }
}